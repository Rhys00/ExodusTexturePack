#version 150
#define FSH
#define SKINFX_FRAGMENT

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <skin_effects.glsl>

uniform sampler2D Sampler0;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
flat in vec4 skinfxEffectV;
flat in vec4 skinfxEffect2V;
flat in vec3 skinfxColorA;
flat in vec3 skinfxColorB;
flat in vec4 skinfxKey;

out vec4 fragColor;

void main() {
    ivec4 effect = ivec4(skinfxEffectV);
    ivec4 effect2 = ivec4(skinfxEffect2V);
    vec3 colorA = skinfxColorA;
    vec3 tint = colorA;
    vec4 color = texture(Sampler0, texCoord0);
    bool fx = effect.x != 0;
    bool fxHere = fx && ((effect.w & FXF_KEY) == 0 || skinfx_is_key(color.rgb, skinfxKey));

    if(fxHere && effect.x == FX_GLITCH) color = skinfx_glitch(Sampler0, texCoord0, color, effect.y, effect.z);
    if(fxHere) {
        color.rgb = skinfx_recolor(effect.x, effect.y, effect.z, color.rgb, texCoord0, tint);
        if(effect2.x != 0) color.rgb = skinfx_recolor(effect2.x, effect2.y, effect2.z, color.rgb, texCoord0, tint);
    }

    if(color.a < 0.1) discard;
    color *= vertexColor * ColorModulator;

    vec3 hurt = fx && (effect.w & FXF_HURT) != 0 ? skinfxColorB : overlayColor.rgb;
    color.rgb = mix(hurt, color.rgb, overlayColor.a);

    if(!(fxHere && (effect.w & FXF_EMISSIVE) != 0)) color *= lightMapColor;
    if(fxHere) {
        vec3 lit = color.rgb;
        color.rgb += skinfx_glow(effect.x, effect.y, effect.z, texCoord0, tint, lit, gl_FragCoord.xy);
        if(effect2.x != 0) color.rgb += skinfx_glow(effect2.x, effect2.y, effect2.z, texCoord0, tint, lit, gl_FragCoord.xy);
        color.a *= skinfx_alpha(effect.x, effect.y, effect.z);
    }

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
