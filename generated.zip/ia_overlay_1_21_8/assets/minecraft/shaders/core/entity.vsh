#version 150
#define VSH
#define SKINFX

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:light.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <skin_effects.glsl>
#moj_import <skin_effects_config.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
flat out vec4 skinfxEffectV;
flat out vec4 skinfxEffect2V;
flat out vec3 skinfxColorA;
flat out vec3 skinfxColorB;
flat out vec4 skinfxKey;

void main() {
    ivec4 metadataEffect;
    ivec4 metadataEffect2;
    vec3 colorA;
    vec3 colorB;
    vec4 key;
    skinfx_detect(Sampler0, metadataEffect, metadataEffect2, colorA, colorB, key);

    ivec4 effect;
    ivec4 effect2;
    skinfx_configure(colorA, effect, effect2);
    skinfxEffectV = vec4(effect);
    skinfxEffect2V = vec4(effect2);
    skinfxColorA = colorA;
    skinfxColorB = colorB;
    skinfxKey = key;

    vec3 skinPosition = skinfx_move(effect, effect2, Position);
    gl_Position = ProjMat * ModelViewMat * vec4(skinPosition, 1.0);
    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    texCoord0 = UV0;
}
