// ---------------------------------------------------------------------------
// 26.3 text-effect fixes
//  * NaN-safe quad reconstruction (always on): each triangle of a glyph quad only
//    carries 3 of the 4 corner varyings, the missing one interpolates to 0 and the
//    old 0/0 divide gave NaN. GL's min/max swallowed it, Vulkan's does not.
//  * Brightness-based shadow detection (always on): fract(Position.z) is unreliable.
//  * SPHEYA_SCREENSPACE_FALLBACK (off by default): lossy workarounds that bypass the
//    reconstruction entirely (screen-space colour/position, no quad scaling).
//    Uncomment the next line only if seams/outline artifacts remain after the fix.
#define SPHEYA_SCREENSPACE_FALLBACK
// ---------------------------------------------------------------------------
#if defined(RENDERTYPE_TEXT) || defined(RENDERTYPE_TEXT_INTENSITY)

struct TextData {
    vec4 color;
    vec4 topColor;
    vec4 backColor;
    vec2 position;
    vec2 characterPosition;
    vec2 localPosition;
    vec2 uv;
    vec2 uvMin;
    vec2 uvMax;
    vec2 uvCenter;
    bool isShadow;
    bool doTextureLookup;
    bool shouldScale;
};

TextData textData;

// Pre-calculated time values (calculate once per frame, not per pixel)
float fastTime;
float medTime;
float slowTime;

void initTimeValues() {
    fastTime = GameTime * 500.0;
    medTime = GameTime * 1200.0;
    slowTime = GameTime * 300.0;
}

bool uvBoundsCheck(vec2 uv, vec2 uvMin, vec2 uvMax) {
    if(isnan(uv.x) || isnan(uv.y)) return true;
    const float error = 0.0001;
    return uv.x < textData.uvMin.x + error || uv.y < textData.uvMin.y + error || uv.x > textData.uvMax.x - error || uv.y > textData.uvMax.y - error;
}

// OPTIMIZED: 4-sample cross pattern instead of 9-sample grid
vec3 textSdf() {
    vec3 value = vec3(0.0, 0.0, 1.0);
    vec2 texelSize = 1.0 / vec2(256.0);
    
    // Check 4 cardinal directions + center
    vec2 offsets[5] = vec2[](
        vec2(0.0, 0.0),
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );
    
    for(int i = 0; i < 5; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

        vec4 s = texture(Sampler0, uv);
        if(s.a >= 0.1) {
            vec3 v = vec3(fract(uv * 256.0), 0.0);
            
            if(offsets[i].x == 0.0) v.x = 0.0;
            if(offsets[i].y == 0.0) v.y = 0.0;
            if(offsets[i].x > 0.0) v.x = 1.0 - v.x;
            if(offsets[i].y > 0.0) v.y = 1.0 - v.y;
            
            v.z = length(v.xy);
            if(v.z < value.z) value = v;
        }
    }
    return value;
}

void override_text_color(vec4 color) {
    textData.color = color;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void override_text_color(vec3 color) {
    textData.color.rgb = color;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void override_shadow_color(vec4 color) {
    if(textData.isShadow) {
        textData.color = color;
        textData.topColor.rgb = color.rgb;
        textData.topColor.a *= color.a;
        textData.backColor.rgb = color.rgb;
        textData.backColor.a *= color.a;
    }
}

void override_shadow_color(vec3 color) {
    override_shadow_color(vec4(color, 1.0));
}

void remove_text_shadow() {
    if(textData.isShadow) textData.color.a = 0.0;
}

void apply_vertical_shadow() {
    if(textData.isShadow) {
        textData.uv.x += 1.0 / 256.0;
        textData.shouldScale = false;
    }
}

void text_translate(vec2 px) {
    textData.uv -= px / 64.0;
    textData.shouldScale = true;
}

void apply_rise(float speed, float height) {
    float t = GameTime * 1200.0 * speed * 1.5;
    float lift = 0.5 - 0.5 * cos(t);              // 0 -> 1 -> 0, smooth at both ends
    text_translate(vec2(0.0, -height * lift));    // negative y = up
}

void apply_shift(float minOff, float maxOff, float vertical, float speed) {
    textData.shouldScale = true;
    float lo = min(minOff, maxOff);
    float dist = floor(abs(maxOff - minOff) + 0.5);
    float off = lo;
    if (dist >= 1.0) {
        float len = dist * 2.0;
        float idx = floor(fract(GameTime * 1200000.0 * speed / 300.0) * len);
        off = lo + min(idx, len - 1.0 - idx);   // same table as TextStyles.rangeLoop
    }
    text_translate(vertical > 0.5 ? vec2(0.0, off) : vec2(off, 0.0));
}

void apply_waving_movement(float speed, float frequency) {
    textData.uv.y += sin(textData.characterPosition.x * 0.1 * frequency - GameTime * 7500.0 * speed) / 64.0;
    textData.shouldScale = false;
}

void apply_waving_movement(float speed) {
    apply_waving_movement(speed, 1.0);
}

void apply_waving_movement() {
    apply_waving_movement(1.0, 1.0);
}

void apply_shaking_movement() {
    float noiseX = noise(textData.characterPosition.x + textData.characterPosition.y + GameTime * 32000.0) - 0.5;
    float noiseY = noise(textData.characterPosition.x - textData.characterPosition.y + GameTime * 32000.0) - 0.5;
    textData.shouldScale = false;
    textData.uv += vec2(noiseX, noiseY) / 128.0;
}

void apply_iterating_movement(float speed, float space) {
    float x = mod(textData.characterPosition.x * 0.4 - GameTime * 18000.0 * speed, (5.0 * space) * TAU);
    if(x > TAU) x = TAU;
    textData.uv.y += (-cos(x) * 0.5 + 0.5) / 64.0;
    textData.shouldScale = false;
}

void apply_iterating_movement() {
    apply_iterating_movement(1.0, 1.0);
}

void apply_flipping_movement(float speed, float space) {
    float t = mod((textData.characterPosition.x * 0.4 - GameTime  * 18000.0 * speed) / TAU, 5.0 * space);
    textData.uv.x = textData.uvCenter.x + (textData.uv.x - textData.uvCenter.x) / (cos(TAU * min(t, 1.0)));
    textData.uv.y = textData.uvCenter.y + (textData.uv.y - textData.uvCenter.y) / (1.0 + 0.1 * sin(TAU * min(t, 1.0)));
    textData.shouldScale = false;
}

void apply_flipping_movement() {
    apply_flipping_movement(1.0, 1.0);
}

void apply_skewing_movement(float speed) {
    float t = GameTime * 1600.0 * speed;
    textData.uv.x = mix(textData.uv.x, textData.uv.x + sin(TAU * t * 0.5) / 256.0, 1.0 - textData.localPosition.y);
    textData.uv.y = mix(textData.uv.y, textData.uvMax.y, -(0.3 + 0.5 * cos(TAU * t)));
    textData.shouldScale = false;
}

void apply_skewing_movement() {
    apply_skewing_movement(1.0);
}

void apply_growing_movement(float speed) {
    vec2 offset = vec2(0.0, 5.0 / 256.0);
    textData.uv = (textData.uv - textData.uvCenter - offset) * (sin(GameTime * 12800.0 * speed) * 0.15 + 0.85) + textData.uvCenter + offset;
    textData.shouldScale = false;
}

void apply_growing_movement() {
    apply_growing_movement(1.0);
}

void apply_spiral_embrace(float speed, float radius) {
    float t = GameTime * 4000.0 * speed;
    float angle = t + textData.characterPosition.x * 0.2;
    
    // Spiral distance from center varies over time
    float spiralDist = sin(t * 0.5) * radius;
    
    vec2 offset = vec2(
        cos(angle) * spiralDist,
        sin(angle) * spiralDist
    );
    
    textData.uv += offset / 128.0;
    textData.shouldScale = false;
}

void apply_dangling(float speed, float swayAmount) {
    float t = GameTime * 3500.0 * speed;
    
    // Pendulum motion
    float angle = sin(t + textData.characterPosition.x * 0.1) * swayAmount;
    
    // Characters further down sway more
    float swayMultiplier = textData.localPosition.y;
    
    textData.uv.x += sin(angle) * swayMultiplier * 1.5 / 128.0;
    
    // Slight vertical movement for realism
    textData.uv.y += (1.0 - cos(angle)) * swayMultiplier * 0.3 / 128.0;
    
    textData.shouldScale = false;
}

void apply_dangling_global(float speed, float swayAmount) {
    float t = GameTime * 3500.0 * speed;
    
    // Same angle for all characters (removed characterPosition offset)
    float angle = sin(t) * swayAmount;
    
    // Characters further down sway more
    float swayMultiplier = textData.localPosition.y;
    
    textData.uv.x += sin(angle) * swayMultiplier * 1.5 / 128.0;
    
    // Slight vertical movement for realism
    textData.uv.y += (1.0 - cos(angle)) * swayMultiplier * 0.3 / 128.0;
    
    textData.shouldScale = false;
}

// Text cracks apart slightly - works in lores too
void apply_crack_movement(float speed, float intensity) {
    float t = GameTime * 6000.0 * speed;
    float crackPhase = sin(t);
    
    if(crackPhase > 0.0) {
        // Use UV coordinates instead of character position for per-pixel variation
        float angle = noise((textData.uv.x + textData.uv.y) * 1000.0) * TAU;
        vec2 crackDir = vec2(cos(angle), sin(angle));
        
        float crackAmount = crackPhase * crackPhase * intensity;
        textData.uv += crackDir * crackAmount / 128.0;
    }
    
    textData.shouldScale = false;
}
void apply_crack_movement() {
    apply_crack_movement(1.0, 1.5);
}

void apply_wave_ride(float speed, float amplitude) {
    float t = GameTime * 5000.0 * speed;
    float swell = textData.characterPosition.x * 0.12 - t;
    float bob = sin(swell) * amplitude;

    textData.uv.y += bob / 256.0;

    float surge = cos(swell) * amplitude * 0.3;
    textData.uv.x += surge / 256.0;

    textData.shouldScale = false;
}

void apply_splash_bounce(float speed, float height) {
    float t = GameTime * 4500.0 * speed;

    float charOffset = textData.characterPosition.x * 0.35;
    float cycle = mod(t - charOffset, TAU);

    float bounce = 0.0;
    if (cycle < PI) {
        // Rising/falling arc (looks like a droplet jump)
        bounce = sin(cycle) * height;
    }

    textData.uv.y -= bounce / 128.0;

    // Slight squash on landing (widen briefly at bottom of arc)
    float squash = (1.0 - smoothstep(0.0, 0.3, cycle)) * 0.15;
    textData.uv.x = textData.uvCenter.x + (textData.uv.x - textData.uvCenter.x) * (1.0 + squash);

    textData.shouldScale = false;
}

void apply_airplane_reveal(float speed, float pauseLen, float travelLen, float holdLen, float edgeWidth) {
    float x = textData.characterPosition.x;
    float cycleLen = pauseLen + travelLen + holdLen;
    float front = GameTime * speed * 240000.0;
    float phase = mod(front - x, cycleLen);

    float revealed = smoothstep(pauseLen - edgeWidth, pauseLen + edgeWidth, phase);
    revealed -= smoothstep(pauseLen + travelLen + holdLen - edgeWidth,
                            pauseLen + travelLen + holdLen + edgeWidth, phase);

    float distFromEdge = abs(phase - pauseLen);
    float glow = 1.0 - smoothstep(0.0, edgeWidth * 2.0, distFromEdge);
    textData.topColor = vec4(1.0, 1.0, 1.0, glow * 0.9);

    textData.uv.y -= glow * glow * 1.0 / 256.0;

    textData.color.a *= revealed;
    textData.shouldScale = false;
}

void apply_typewriter(float speed, float pauseLen, float travelLen, float holdLen,
                      float charWidth, float cursorWidth, vec3 cursorColor,
                      float sectionWidth, float lead, float ulOffset, float ulThickness,
                      float ulExtend, vec3 ulColor) {
    textData.shouldScale = true;

    float x = textData.characterPosition.x;
    float cycleLen = pauseLen + travelLen + holdLen;
    float front = GameTime * speed * 240000.0;

    vec2 quadPx = (textData.uvMax - textData.uvMin) * 128.0;
    vec2 px = (textData.uv - textData.uvMin) * 128.0;

    float phase = mod(front - x, cycleLen);
    bool revealed = phase >= pauseLen;
    bool isNext = phase >= pauseLen - charWidth && phase < pauseLen;

    bool underlineOn;
    if (sectionWidth > 0.0) {
        float sectionStart = floor(x / sectionWidth) * sectionWidth;
        float phaseS = mod(front - sectionStart, cycleLen);
        underlineOn = phaseS >= pauseLen - lead && phaseS < pauseLen + sectionWidth;
    } else {
        underlineOn = phase >= pauseLen - lead;
    }

    if (underlineOn) {
        bool inLine = px.y >= quadPx.y + ulOffset && px.y < quadPx.y + ulOffset + ulThickness
                   && px.x >= -ulExtend * 0.5 && px.x < quadPx.x + ulExtend * 0.5;
        if (inLine) {
            vec3 c = ulColor;
            if (textData.isShadow) c *= 0.25;
            textData.backColor = vec4(c, 1.0);
        }
    }

    if (isNext) {
        float blink = step(0.5, fract(GameTime * 1200.0));
        if (px.x >= 0.0 && px.x < cursorWidth && px.y >= 0.0 && px.y < quadPx.y && blink > 0.5) {
            textData.backColor = vec4(cursorColor, 1.0);
        }
    }

    if (!revealed) textData.doTextureLookup = false;
}

// Text melts downward like liquid
void apply_melting_movement(float speed, float viscosity) {
    float t = GameTime * 5000.0 * speed;
    float melt = textData.characterPosition.x * 0.1 + t;
    float drip = sin(melt) * viscosity;
    
    // More melting at the bottom of each character
    float meltAmount = smoothstep(0.0, 1.0, textData.localPosition.y);
    textData.uv.y += (drip * meltAmount) / 128.0;
    
    // Slight horizontal wobble as it melts
    textData.uv.x += (sin(melt * 2.0) * 0.3 * meltAmount) / 128.0;
    textData.shouldScale = false;
}
void apply_melting_movement() {
    apply_melting_movement(1.0, 2.0);
}

// OPTIMIZED: 4 samples instead of 9
void apply_outline(vec3 color) {
    textData.shouldScale = false;

    if(textData.isShadow) {
        color *= 0.25;
        textData.color.rgb = color;
    }

    vec2 texelSize = 1.0 / vec2(256.0);
    
    // Check cardinal directions only
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

        if(texture(Sampler0, uv).a >= 0.1) {
            textData.backColor = vec4(color, 1.0);
            return;
        }
    }
}

// OPTIMIZED: 4 samples instead of 9
void apply_thin_outline(vec3 color) {
    textData.shouldScale = false;

    if(textData.isShadow) {
        color *= 0.25;
        textData.color.rgb = color;
    }

    vec2 texelSize = 0.5 / vec2(256.0);
    
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

        if(texture(Sampler0, uv).a >= 0.1) {
            textData.backColor = vec4(color, 1.0);
            return;
        }
    }
}

void apply_gradient(vec3 color1, vec3 color2) {
    textData.color.rgb = mix(color1, color2, (textData.uv.y - textData.uvMin.y) / (textData.uvMax.y - textData.uvMin.y));
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_3(vec3 color1, vec3 color2, vec3 color3) {
    float t = 0.006 * (textData.position.x + textData.position.y) - fastTime * 10.0;
    float smoothT = fract(t / (2.0 * 3.14159)) * 3.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else {
        resultColor = mix(color3, color1, smoothT - 2.0);
    }

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
    textData.shouldScale = true;
}

// OPTIMIZED: Pre-calculate wave value
void apply_animated_gradient_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7) {
    float t = 0.003 * (textData.position.x + textData.position.y) - fastTime;
    float smoothT = fract(t) * 7.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color7, smoothT - 5.0);
    } else {
        resultColor = mix(color7, color1, smoothT - 6.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5) {
    float t = 0.003 * (textData.position.x + textData.position.y) - fastTime;
    float smoothT = fract(t) * 5.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else {
        resultColor = mix(color5, color1, smoothT - 4.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_7_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7) {
    float t = 0.003 * (textData.position.x + textData.position.y) - fastTime;
    float smoothT = fract(t) * 12.0;
    
    // Pre-calculate for fewer operations
    float idx = floor(smoothT);
    float blend = fract(smoothT);
    
    // Use step functions to avoid branching
    vec3 resultColor = vec3(0.0);
    
    // Forward transitions (0-6)
    resultColor += mix(color1, color2, blend) * (1.0 - step(1.0, idx)) * step(0.0, idx);
    resultColor += mix(color2, color3, blend) * step(1.0, idx) * (1.0 - step(2.0, idx));
    resultColor += mix(color3, color4, blend) * step(2.0, idx) * (1.0 - step(3.0, idx));
    resultColor += mix(color4, color5, blend) * step(3.0, idx) * (1.0 - step(4.0, idx));
    resultColor += mix(color5, color6, blend) * step(4.0, idx) * (1.0 - step(5.0, idx));
    resultColor += mix(color6, color7, blend) * step(5.0, idx) * (1.0 - step(6.0, idx));
    
    // Backward transitions (6-12)
    resultColor += mix(color7, color6, blend) * step(6.0, idx) * (1.0 - step(7.0, idx));
    resultColor += mix(color6, color5, blend) * step(7.0, idx) * (1.0 - step(8.0, idx));
    resultColor += mix(color5, color4, blend) * step(8.0, idx) * (1.0 - step(9.0, idx));
    resultColor += mix(color4, color3, blend) * step(9.0, idx) * (1.0 - step(10.0, idx));
    resultColor += mix(color3, color2, blend) * step(10.0, idx) * (1.0 - step(11.0, idx));
    resultColor += mix(color2, color1, blend) * step(11.0, idx);
    
    // Optimized wave
    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);
    
    // Branchless shadow multiplier
    textData.color.rgb = resultColor * mix(1.0, 0.25, float(textData.isShadow));
}

void apply_animated_gradient_6_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6) {
    float t = 0.003 * (textData.position.x + textData.position.y) - fastTime;
    float smoothT = fract(t) * 10.0;
    
    // Pre-calculate for fewer operations
    float idx = floor(smoothT);
    float blend = fract(smoothT);
    
    // Use step functions to avoid branching
    vec3 resultColor = vec3(0.0);
    
    // Forward transitions (0-5)
    resultColor += mix(color1, color2, blend) * (1.0 - step(1.0, idx)) * step(0.0, idx);
    resultColor += mix(color2, color3, blend) * step(1.0, idx) * (1.0 - step(2.0, idx));
    resultColor += mix(color3, color4, blend) * step(2.0, idx) * (1.0 - step(3.0, idx));
    resultColor += mix(color4, color5, blend) * step(3.0, idx) * (1.0 - step(4.0, idx));
    resultColor += mix(color5, color6, blend) * step(4.0, idx) * (1.0 - step(5.0, idx));
    
    // Backward transitions (5-10)
    resultColor += mix(color6, color5, blend) * step(5.0, idx) * (1.0 - step(6.0, idx));
    resultColor += mix(color5, color4, blend) * step(6.0, idx) * (1.0 - step(7.0, idx));
    resultColor += mix(color4, color3, blend) * step(7.0, idx) * (1.0 - step(8.0, idx));
    resultColor += mix(color3, color2, blend) * step(8.0, idx) * (1.0 - step(9.0, idx));
    resultColor += mix(color2, color1, blend) * step(9.0, idx);
    
    // Optimized wave
    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);
    
    // Branchless shadow multiplier
    textData.color.rgb = resultColor * mix(1.0, 0.25, float(textData.isShadow));
}

void apply_character_cycle(vec3 startRGB, vec3 endRGB, float speed, float frequency) {
    float timeOffset = fastTime * speed;
    float positionOffset = textData.characterPosition.x * frequency;
    float wave = sin(positionOffset - timeOffset) * 0.5 + 0.5;

    textData.color.rgb = mix(startRGB, endRGB, wave);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_rainbow() {
    float speed = 2.5;
    vec3 hsvColor = vec3(0.002 * (textData.position.x + textData.position.y) - slowTime * speed, 0.7, 1.0);
    textData.color.rgb = hsvToRgb(hsvColor);
    if(textData.isShadow) textData.color.rgb *= 0.25;
    textData.shouldScale = true;
}

void apply_pastel_rainbow() {
    float speed = 2.5;
    vec3 hsvColor = vec3(0.002 * (textData.position.x + textData.position.y) - slowTime * speed, 0.2, 0.95);
    textData.color.rgb = hsvToRgb(hsvColor);
    if(textData.isShadow) textData.color.rgb *= 0.25;
    textData.shouldScale = true;
}

// OPTIMIZED: Simplified noise function
float fast_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float fast_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = fast_hash(i);
    float b = fast_hash(i + vec2(1.0, 0.0));
    float c = fast_hash(i + vec2(0.0, 1.0));
    float d = fast_hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// OPTIMIZED: 2 octaves instead of 4
float fast_fbm(vec2 p) {
    float value = 0.0;
    value += 0.5 * fast_noise(p);
    value += 0.25 * fast_noise(p * 2.0);
    return value;
}

void apply_water(vec3 waterColor, vec3 streakColor, vec3 hotColor, vec3 mistColor, float level, float amplitude, float speed, float frequency) {
    textData.shouldScale = true;

    vec2 uvSize = textData.uvMax - textData.uvMin;
    float uNorm = (uvSize.x > 0.0001) ? (textData.uv.x - textData.uvMin.x) / uvSize.x : 0.5;
    float vNorm = (uvSize.y > 0.0001) ? (textData.uv.y - textData.uvMin.y) / uvSize.y : 0.5;

    float lvl = clamp(level, 0.0, 1.0);
    float freq = max(frequency, 0.5);
    float t = GameTime * speed * 12000.0;

    float wave = sin(uNorm * TAU * freq + t) * 0.6
               + sin(uNorm * TAU * freq * 2.0 + t * 1.3) * 0.4;
    wave *= amplitude * 0.08;

    float waterLine = (1.0 - lvl) + wave;

    if (vNorm < waterLine) {
        float skyT = vNorm / max(waterLine, 0.0001);
        vec3 skyTop = vec3(0.6, 0.85, 1.0);
        vec3 skyHorizon = vec3(0.85, 0.95, 1.0);
        vec3 baseSky = mix(skyTop, skyHorizon, skyT);

        textData.color.rgb = baseSky;

        #ifdef FSH
            float st = GameTime * 4000.0 * speed;
            vec2 sp = vec2(gl_FragCoord.xy);

            float sparkle = 0.0;
            for (int i = 0; i < 3; i++) {
                float fi = float(i);
                vec2 cell = floor(sp / (8.0 + fi * 3.0) + vec2(st * (0.02 + fi * 0.01), fi * 13.0));
                float flicker = fract(sin(dot(cell, vec2(12.9898, 78.233)) + fi * 7.0) * 43758.5453);
                float twinkle = sin(st * 0.01 + flicker * 30.0) * 0.5 + 0.5;
                sparkle += step(0.93, flicker) * twinkle;
            }
            sparkle = clamp(sparkle, 0.0, 1.0);

            textData.color.rgb = mix(baseSky, mistColor, sparkle * 0.8);
        #endif

        if (textData.isShadow) textData.color.rgb *= 0.25;
        return;
    }

    vec2 uv = textData.uv * 256.0 * 0.5;

    vec4 s1;
    {
        vec2 p = floor(mod(uv, 128.));
        s1 = vec4(waterColor, 0.);
        float row = floor(p.y / 3.);
        float part = mod(p.y, 3.);
        float ti = fract(sin(dot(vec2(row * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);

        float rowWave = sin(row * 0.4 + GameTime * 4000.0 * speed) * 6.0;

        float scrollSpeed = 9.0 + ti * 9.0;
        float where = mod(GameTime * scrollSpeed * speed * 50.0 - floor(ti * 24. + abs(part - 1.)) - p.x + rowWave, 20.);
        if (where < 10. && part < 3.) {
            float b = 1. - where / 10.;
            s1.a += b * 1.4;
            if (b > 0.35) s1.rgb += streakColor * b;
            if (b > 0.65) s1.rgb += hotColor * (b - 0.65);
        }
    }

    vec4 s2;
    {
        vec2 p = floor(mod(uv * 2. + vec2(63., 722.), 128.));
        s2 = vec4(waterColor, 0.);
        float row = floor(p.y / 3.);
        float part = mod(p.y, 3.);
        float ti = fract(sin(dot(vec2(row * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);

        float rowWave = sin(row * 0.5 - GameTime * 3500.0 * speed + 1.7) * 6.0;

        float scrollSpeed = 9.0 + ti * 9.0;
        float where = mod(GameTime * scrollSpeed * speed * 50.0 - floor(ti * 24. + abs(part - 1.)) - p.x + rowWave, 20.);
        if (where < 10. && part < 3.) {
            float b = 1. - where / 10.;
            s2.a += b * 1.4;
            if (b > 0.35) s2.rgb += streakColor * b;
            if (b > 0.65) s2.rgb += hotColor * (b - 0.65);
        }
    }

    float depth = (1.0 - waterLine > 0.0001)
        ? (vNorm - waterLine) / (1.0 - waterLine)
        : 0.5;
    depth = clamp(depth, 0.0, 1.0);

    vec3 deepBase = waterColor * (1.0 - depth * 0.3);
    vec3 rgbsum = clamp(s1.rgb + s2.rgb * 0.4, 0.0, 1.5);
    vec3 col = mix(deepBase, rgbsum, clamp(s1.a + s2.a * 0.4, 0.0, 1.0));

    float surfaceGlow = smoothstep(0.0, 0.05, depth) * (1.0 - smoothstep(0.0, 0.10, depth));
    col = mix(col, mix(hotColor, vec3(1.0), 0.3), surfaceGlow * 0.5);

    col = clamp(col, 0.0, 1.0);
    textData.color.rgb = col;
    if (textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_water(vec3 waterColor, vec3 streakColor, vec3 hotColor, float level, float speed) {
    apply_water(waterColor, streakColor, hotColor, vec3(0.7, 0.85, 0.9), level, 1.0, speed, 1.2);
}

void apply_water(vec3 waterColor, vec3 streakColor, vec3 hotColor, float level) {
    apply_water(waterColor, streakColor, hotColor, vec3(0.7, 0.85, 0.9), level, 1.0, 1.0, 1.2);
}

void apply_water_outline(vec3 waterColor, vec3 streakColor, vec3 hotColor, vec3 mistColor, float level, float amplitude, float speed, float frequency) {
    textData.shouldScale = false;

    float currentAlpha = texture(Sampler0, textData.uv).a;
    if (currentAlpha >= 0.1) {
    }

    vec2 texelSize = 0.26 / vec2(64.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            vec2 uvSize = textData.uvMax - textData.uvMin;
            float uNorm = (uvSize.x > 0.0001) ? (textData.uv.x - textData.uvMin.x) / uvSize.x : 0.5;
            float vNorm = (uvSize.y > 0.0001) ? (textData.uv.y - textData.uvMin.y) / uvSize.y : 0.5;

            float lvl = clamp(level, 0.0, 1.0);
            float freq = max(frequency, 0.5);
            float t = GameTime * speed * 12000.0;

            float wave = sin(uNorm * TAU * freq + t) * 0.6
                       + sin(uNorm * TAU * freq * 2.0 + t * 1.3) * 0.4;
            wave *= amplitude * 0.08;

            float waterLine = (1.0 - lvl) + wave;

            vec3 outlineColor;

            if (vNorm < waterLine) {
                float skyT = vNorm / max(waterLine, 0.0001);
                vec3 skyTop = vec3(0.6, 0.85, 1.0);
                vec3 skyHorizon = vec3(0.85, 0.95, 1.0);
                outlineColor = mix(skyTop, skyHorizon, skyT) * 0.5;
            } else {
                vec2 muv = textData.uv * 256.0 * 0.5;

                vec4 s1;
                {
                    vec2 p = floor(mod(muv, 128.));
                    s1 = vec4(0., 0., 0., 0.);
                    float row = floor(p.y / 3.);
                    float part = mod(p.y, 3.);
                    float ti = fract(sin(dot(vec2(row * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);

                    float rowWave = sin(row * 0.4 + GameTime * 4000.0 * speed) * 6.0;

                    float scrollSpeed = 9.0 + ti * 9.0;
                    float where = mod(GameTime * scrollSpeed * speed * 50.0 - floor(ti * 24. + abs(part - 1.)) - p.x + rowWave, 20.);
                    if (where < 10. && part < 3.) {
                        float b = 1. - where / 10.;
                        s1.a += b * 1.4;
                        if (b > 0.35) s1.rgb += streakColor;
                        if (b > 0.65) s1.rgb += hotColor;
                    }
                }

                vec4 s2;
                {
                    vec2 p = floor(mod(muv * 2. + vec2(63., 722.), 128.));
                    s2 = vec4(0., 0., 0., 0.);
                    float row = floor(p.y / 3.);
                    float part = mod(p.y, 3.);
                    float ti = fract(sin(dot(vec2(row * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);

                    float rowWave = sin(row * 0.5 - GameTime * 3500.0 * speed + 1.7) * 6.0;

                    float scrollSpeed = 9.0 + ti * 9.0;
                    float where = mod(GameTime * scrollSpeed * speed * 50.0 - floor(ti * 24. + abs(part - 1.)) - p.x + rowWave, 20.);
                    if (where < 10. && part < 3.) {
                        float b = 1. - where / 10.;
                        s2.a += b * 1.4;
                        if (b > 0.35) s2.rgb += streakColor;
                        if (b > 0.65) s2.rgb += hotColor;
                    }
                }

                float depth = (1.0 - waterLine > 0.0001)
                    ? (vNorm - waterLine) / (1.0 - waterLine)
                    : 0.5;
                depth = clamp(depth, 0.0, 1.0);

                vec3 deepBase = mix(waterColor, waterColor * 0.45, depth);
                vec3 rgbsum = clamp(s1.rgb + s2.rgb, 0.0, 1.0);
                outlineColor = mix(deepBase, rgbsum, min((s1.a + s2.a * 0.4), 1.0));
                outlineColor *= 0.45;
            }

            if (textData.isShadow) outlineColor *= 0.25;
            textData.backColor = vec4(outlineColor, 1.0);
            return;
        }
    }
}

void apply_water_outline(vec3 waterColor, vec3 streakColor, vec3 hotColor, float level, float speed) {
    apply_water_outline(waterColor, streakColor, hotColor, vec3(0.7, 0.85, 0.9), level, 1.0, speed, 1.2);
}

void apply_water_outline(vec3 waterColor, vec3 streakColor, vec3 hotColor, float level) {
    apply_water_outline(waterColor, streakColor, hotColor, vec3(0.7, 0.85, 0.9), level, 1.0, 1.0, 1.2);
}

// OPTIMIZED: Reduced complexity fractal effects
void apply_config_fractal_colors(vec3 color1, vec3 color2, vec3 color3) {
    #ifdef FSH
        vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        float shade = fast_fbm(uv + medTime);
        shade = pow(shade, 0.7);

        vec3 blend1 = mix(color1, color2, shade);
        vec3 blend2 = mix(color2, color3, shade);
        textData.color.rgb = mix(blend1, blend2, shade);

        if(textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

// Red fractal helper functions
float red_fractal_rand(vec2 n) {
    return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
}

float red_fractal_noise(vec2 p){
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u*u*(3.0-2.0*u);

    float res = mix(
        mix(red_fractal_rand(ip),red_fractal_rand(ip+vec2(1.0,0.0)),u.x),
        mix(red_fractal_rand(ip+vec2(0.0,1.0)),red_fractal_rand(ip+vec2(1.0,1.0)),u.x),u.y);
    return res*res;
}

float red_fractal_fbm(vec2 p) {
    return 0.516129 * red_fractal_noise(p + GameTime * 1200.0);
}

// Pink fractal helper functions
float pink_fractal_rand(vec2 n) {
    return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
}

float pink_fractal_noise(vec2 p){
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u*u*(3.0-2.0*u);

    float res = mix(
        mix(pink_fractal_rand(ip),pink_fractal_rand(ip+vec2(1.0,0.0)),u.x),
        mix(pink_fractal_rand(ip+vec2(0.0,1.0)),pink_fractal_rand(ip+vec2(1.0,1.0)),u.x),u.y);
    return res*res;
}

float pink_fractal_fbm(vec2 p) {
    return 0.516129 * pink_fractal_noise(p + GameTime * 1200.0);
}

// The actual effect functions
void apply_red_fractal() {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
        float shade = red_fractal_fbm(uv);
        shade = pow(shade, 0.7);
        vec3 deepRed = vec3(0.4, 0.0, 0.0);
        vec3 brightRed = vec3(1.0, 0.0, 0.0);
        vec3 lightRed = vec3(1.0, 0.4, 0.4);
        vec3 paleRed = vec3(1.0, 0.5, 0.5);
        vec3 veryPaleRed = vec3(1.0, 0.9, 0.9);
        vec3 pureWhite = vec3(1.0, 1.0, 1.0);
        vec3 color1 = mix(deepRed, brightRed, shade);
        vec3 color2 = mix(brightRed, lightRed, shade);
        vec3 color3 = mix(lightRed, paleRed, shade);
        vec3 color4 = mix(paleRed, veryPaleRed, shade);
        vec3 color5 = mix(veryPaleRed, pureWhite, shade);
        vec3 finalColor1 = mix(mix(color1, color2, shade), mix(color3, color4, shade), shade);
        vec3 finalColor2 = mix(finalColor1, color5, shade);
        textData.color.rgb = finalColor2;
        if(textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_pink_fractal() {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
        float shade = pink_fractal_fbm(uv);
        vec3 lighter_dark_pink = vec3(0.6, -0.6, 0.6);
        textData.color.rgb = mix(lighter_dark_pink, vec3(3.25, 3.136, 1.75), shade);
        if(textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_embers(vec3 color1, vec3 color2, vec3 color3, vec3 color4) {
    #ifdef FSH
        float t = medTime * 2.0;

        float flicker = fast_noise(vec2(textData.position.x * 0.35, textData.position.y * 0.35 - t * 2.0));
        float heat = clamp(textData.localPosition.y * 0.8 + (flicker - 0.5) * 0.9 + 0.1, 0.0, 1.0);
        float smoothT = heat * 3.15;

        vec3 resultColor;
        if (smoothT < 1.0) {
            resultColor = mix(color1, color2, smoothT);
        } else if (smoothT < 2.0) {
            resultColor = mix(color2, color3, smoothT - 1.0);
        } else {
            resultColor = mix(color3, color4, smoothT - 2.0);
        }

        textData.color.rgb = resultColor;
        if(textData.isShadow) textData.color.rgb *= 0.25;
    #endif
    textData.shouldScale = true;
}

void apply_embers_outline(vec3 color1, vec3 color2, vec3 color3, vec3 color4) {
    textData.shouldScale = false;

    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) {
        return; 
    }

    vec2 texelSize = 0.26 / vec2(64.0);

    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float t = medTime * 2.0;

                float flicker = fast_noise(vec2(textData.position.x * 0.35, textData.position.y * 0.35 - t * 2.0));
                float heat = clamp(textData.localPosition.y * 0.8 + (flicker - 0.5) * 0.9 + 0.1, 0.0, 1.0);
                float smoothT = heat * 3.15;

                vec3 emberColor;
                if (smoothT < 1.0) {
                    emberColor = mix(color1, color2, smoothT);
                } else if (smoothT < 2.0) {
                    emberColor = mix(color2, color3, smoothT - 1.0);
                } else {
                    emberColor = mix(color3, color4, smoothT - 2.0);
                }

                vec3 outlineColor = emberColor * 0.675;

                if(textData.isShadow) {
                    outlineColor *= 0.25;
                }

                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_underline_gradient(vec3 color1, vec3 color2, float speed, float frequency,
                              float offset, float thickness, float extend) {
    textData.shouldScale = true;

    vec2 quadPx = (textData.uvMax - textData.uvMin) * 128.0;
    vec2 px = (textData.uv - textData.uvMin) * 128.0;

    bool inLine = px.y >= quadPx.y + offset && px.y < quadPx.y + offset + thickness
               && px.x >= -extend * 0.5 && px.x < quadPx.x + extend * 0.5;

    if (inLine) {
        float wave = sin(textData.position.x * frequency - fastTime * speed) * 0.5 + 0.5;
        vec3 c = mix(color1, color2, wave);
        if (textData.isShadow) c *= 0.25;
        textData.backColor = vec4(c, 1.0);
    }
}

void apply_box_gradient(vec3 color1, vec3 color2, float speed, float frequency,
                        float pad, float thickness, float extend,
                        bool leftEdge, bool rightEdge, float leftGap, float grow) {
    textData.shouldScale = true;

    vec2 quadPx = (textData.uvMax - textData.uvMin) * 128.0;
    vec2 px = (textData.uv - textData.uvMin) * 128.0;

    float x0 = -extend * 0.5 - (leftEdge ? leftGap + grow : 0.0);
    float x1 = quadPx.x + extend * 0.5 + (rightEdge ? grow : 0.0);
    float y0 = -pad - grow;
    float y1 = quadPx.y + pad + grow;

    bool inY = px.y >= y0 && px.y < y1;
    bool inX = px.x >= x0 && px.x < x1;

    bool top    = inX && px.y >= y0 && px.y < y0 + thickness;
    bool bottom = inX && px.y >= y1 - thickness && px.y < y1;
    bool left   = leftEdge  && inY && px.x >= x0 && px.x < x0 + thickness;
    bool right  = rightEdge && inY && px.x >= x1 - thickness && px.x < x1;

    if (top || bottom || left || right) {
        float wave = sin(textData.position.x * frequency - fastTime * speed) * 0.5 + 0.5;
        vec3 c = mix(color1, color2, wave);
        if (textData.isShadow) c *= 0.25;
        textData.backColor = vec4(c, 1.0);
    }
}

void apply_caged_text(vec3 color1, vec3 color2, float speed, float frequency,
                      float pad, float thickness, float extend,
                      bool leftEdge, bool rightEdge, float leftGap, float grow,
                      float bounceX, float bounceY, float bounceSpeed,
                      float glitchIntensity, float glitchSpeed, float glitchAmount,
                      bool hideText) {
    textData.shouldScale = true;

    float t = GameTime * 1200.0 * bounceSpeed;
    float tx = abs(fract(t * 0.73) - 0.5) * 2.0;
    float ty = abs(fract(t * 1.00) - 0.5) * 2.0;
    float impact = max(smoothstep(0.85, 1.0, tx), smoothstep(0.85, 1.0, ty));

    float gI = glitchIntensity + impact * 0.5;
    float gt = floor(GameTime * glitchSpeed * 6000.0);

    vec2 quadPx = (textData.uvMax - textData.uvMin) * 128.0;
    vec2 px = (textData.uv - textData.uvMin) * 128.0;

    float row = floor(px.y);
    float col = floor(textData.characterPosition.x + px.x);
    float dx = 0.0;
    float dy = 0.0;
    if (random(vec2(row, gt)) < gI)
        dx = (random(vec2(row, gt + 1.0)) * 2.0 - 1.0) * glitchAmount;
    if (random(vec2(col, gt + 2.0)) < gI)
        dy = (random(vec2(col, gt + 3.0)) * 2.0 - 1.0) * glitchAmount;

    float x0 = -extend * 0.5 - (leftEdge ? leftGap + grow : 0.0) + dx;
    float x1 = quadPx.x + extend * 0.5 + (rightEdge ? grow : 0.0) + dx;
    float y0 = -pad - grow + dy;
    float y1 = quadPx.y + pad + grow + dy;

    bool inY = px.y >= y0 && px.y < y1;
    bool inX = px.x >= x0 && px.x < x1;

    bool top    = inX && px.y >= y0 && px.y < y0 + thickness;
    bool bottom = inX && px.y >= y1 - thickness && px.y < y1;
    bool left   = leftEdge  && inY && px.x >= x0 && px.x < x0 + thickness;
    bool right  = rightEdge && inY && px.x >= x1 - thickness && px.x < x1;

    bool dropped = random(vec2(col + row * 7.0, gt + 4.0)) < gI * 0.3;

    if ((top || bottom || left || right) && !dropped) {
        float wave = sin(textData.position.x * frequency - fastTime * speed) * 0.5 + 0.5;
        vec3 c = mix(color1, color2, wave);
        if (dx != 0.0 || dy != 0.0) c *= 0.35; // darken on glitched pixels
        if (textData.isShadow) c *= 0.25;
        textData.backColor = vec4(c, 1.0);
    }

    vec2 shift = vec2((tx * 2.0 - 1.0) * bounceX, (ty * 2.0 - 1.0) * bounceY);
    textData.uv -= shift / 256.0;

    if (hideText && (leftEdge || rightEdge)) {
        textData.doTextureLookup = false;
    }
}

void apply_glitch(float intensity, float speed) {
    textData.shouldScale = true;
    float time = floor(GameTime * speed * 6000.0);
    float glitchLine = floor(textData.uv.y * 64.0);
    if (random(vec2(glitchLine, time)) < intensity) {
        float offset = (random(vec2(glitchLine, time + 1.0)) * 2.0 - 1.0) * 3.0 / 256.0;
        textData.uv.x += offset;
        textData.uv = clamp(textData.uv, textData.uvMin, textData.uvMax);
    }
    textData.shouldScale = true;
}

void apply_egg_crack(float intensity, float speed) {
    textData.shouldScale = false;
    float time = floor(GameTime * speed * 6000.0);
    float crackLine = floor(textData.uv.x * 128.0); // split by column not row
    
    if (random(vec2(crackLine, time)) < intensity) {
        float offset = (random(vec2(crackLine, time + 1.0)) * 2.0 - 1.0) * 2.0 / 128.0;
        textData.uv.y += offset;
        textData.uv = clamp(textData.uv, textData.uvMin, textData.uvMax);
    }
}

void apply_hopping_movement(float speed) {
    float t = GameTime * 3000.0 * speed;
    float charOffset = textData.characterPosition.x * 0.08;
    
    // Hop = fast up, slow fall (like a bounce)
    float hop = -abs(sin(t + charOffset));
    textData.uv.y += hop * 1.2 / 128.0;
    
    // Slight squish on landing
    float squish = abs(cos(t + charOffset)) * 0.3;
    textData.uv.x += sin(charOffset) * squish * 0.4 / 128.0;
    
    textData.shouldScale = false;
}

void apply_rainbow_fractal() {
    #ifdef FSH
        vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        float fractalShade = fast_fbm(uv + medTime);
        
        vec2 smoothCoord = vec2(gl_FragCoord.xy);
        float baseHue = 0.003 * (smoothCoord.x + smoothCoord.y) - slowTime;
        
        float hue = mod(baseHue + fractalShade * 1.0, 1.0); // Full fractal influence restored

        textData.color.rgb = hsvToRgb(vec3(hue, 0.7, 1.0));

        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_pale_rainbow_fractal() {
    #ifdef FSH
        vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        float fractalShade = fast_fbm(uv + medTime);
        
        vec2 smoothCoord = vec2(gl_FragCoord.xy);
        float baseHue = 0.003 * (smoothCoord.x + smoothCoord.y) - slowTime;
        
        float hue = mod(baseHue + fractalShade * 1.0, 1.0);
        textData.color.rgb = hsvToRgb(vec3(hue, 0.38, 0.95));
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_magma() {
const vec3 MAGMA_RED = vec3(0.4, 0.06, 0.06);
const vec3 MAGMA_BRIGHT = vec3(0.05, 0.45, 0.05);
const vec3 MAGMA_MAX = vec3(0.375);

    vec2 uv = textData.uv * 256.0 * 0.5;

    vec4 s1;
    {
        vec2 p = floor(mod(uv, 128.));
        s1 = vec4(1., 0., 0., 0.);
        float column = floor(p.x / 3.);
        float part = mod(p.x, 3.);
        float t = fract(sin(dot(vec2(column * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);
        float where = mod(floor(GameTime * (6000. + floor(t * 6000.))) - floor(t * 24. + abs(part - 1.)) - p.y, 20.);
        if (where < 10. && part < 3.) {
            float b = 1. - where / 10.;
            s1.a += b * 1.4;
            if (b > 0.35) s1.rgb += MAGMA_BRIGHT;
            if (b > 0.65) s1.rgb += MAGMA_MAX;
        }
    }

    vec4 s2;
    {
        vec2 p = floor(mod(uv * 2. + vec2(722., 63.), 128.));
        s2 = vec4(1., 0., 0., 0.);
        float column = floor(p.x / 3.);
        float part = mod(p.x, 3.);
        float t = fract(sin(dot(vec2(column * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);
        float where = mod(floor(GameTime * (6000. + floor(t * 6000.))) - floor(t * 24. + abs(part - 1.)) - p.y, 20.);
        if (where < 10. && part < 3.) {
            float b = 1. - where / 10.;
            s2.a += b * 1.4;
            if (b > 0.35) s2.rgb += MAGMA_BRIGHT;
            if (b > 0.65) s2.rgb += MAGMA_MAX;
        }
    }

    vec3 col = MAGMA_RED * 3.;
    vec3 rgbsum = floor((s1.rgb + s2.rgb) * 4. + 0.5) / 4.;
    col = mix(col, rgbsum, min((s1.a + s2.a * 0.4), 1.0));

    textData.color.rgb = col;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    textData.shouldScale = true;
}

void apply_magma_outline() {
    textData.shouldScale = false;
    vec2 texelSize = 0.26 / vec2(64.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            const vec3 MAGMA_RED = vec3(0.55, 0.045, 0.045);
            const vec3 MAGMA_BRIGHT = vec3(0.45, 0.06, 0.0);
            const vec3 MAGMA_MAX = vec3(0.55, 0.11, 0.0);

            vec2 muv = textData.uv * 256.0 * 0.5;

            vec4 s1;
            {
                vec2 p = floor(mod(muv, 128.));
                s1 = vec4(1., 0., 0., 0.);
                float column = floor(p.x / 3.);
                float part = mod(p.x, 3.);
                float t = fract(sin(dot(vec2(column * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);
                float where = mod(floor(GameTime * (6000. + floor(t * 6000.))) - floor(t * 24. + abs(part - 1.)) - p.y, 20.);
                if (where < 10. && part < 3.) {
                    float b = 1. - where / 10.;
                    s1.a += b * 1.4;
                    if (b > 0.35) s1.rgb += MAGMA_BRIGHT;
                    if (b > 0.65) s1.rgb += MAGMA_MAX;
                }
            }

            vec4 s2;
            {
                vec2 p = floor(mod(muv * 2. + vec2(722., 63.), 128.));
                s2 = vec4(1., 0., 0., 0.);
                float column = floor(p.x / 3.);
                float part = mod(p.x, 3.);
                float t = fract(sin(dot(vec2(column * 63., 0.), vec2(12.9898, 4.1414))) * 43758.5453);
                float where = mod(floor(GameTime * (6000. + floor(t * 6000.))) - floor(t * 24. + abs(part - 1.)) - p.y, 20.);
                if (where < 10. && part < 3.) {
                    float b = 1. - where / 10.;
                    s2.a += b * 1.4;
                    if (b > 0.35) s2.rgb += MAGMA_BRIGHT;
                    if (b > 0.65) s2.rgb += MAGMA_MAX;
                }
            }

            vec3 col = MAGMA_RED * 3.;
            vec3 rgbsum = floor((s1.rgb + s2.rgb) * 4. + 0.5) / 4.;
            col = mix(col, rgbsum, min((s1.a + s2.a * 0.4), 1.0));
            col *= 0.15;

            if(textData.isShadow) col *= 0.25;
            textData.backColor = vec4(col, 1.0);
            return;
        }
    }
}

void apply_pastel_outline() {
    textData.shouldScale = false;
    vec2 texelSize = 0.26 / vec2(64.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH

                vec2 fragUV = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
                float fractalShade = fast_fbm(fragUV + medTime);
                vec2 smoothCoord = vec2(gl_FragCoord.xy);
                float baseHue = 0.003 * (smoothCoord.x + smoothCoord.y) - slowTime;
                float hue = mod(baseHue + fractalShade * 1.0, 1.0);
                
                vec3 outlineColor = hsvToRgb(vec3(hue, 0.55, 0.60)); // Same hue, darker
                if(textData.isShadow) {
                    outlineColor *= 0.25;
                }
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_color_outline(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    textData.shouldScale = false;
    vec2 texelSize = 0.26 / vec2(64.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                vec2 fragUV = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
                float fractalShade = fast_fbm(fragUV + medTime * speed);

                vec2 smoothCoord = vec2(gl_FragCoord.xy);
                float baseHue = 0.003 * (smoothCoord.x + smoothCoord.y) - slowTime * speed;
                float hue = mod(baseHue + fractalShade * 3.0, 1.0);

                float colorIndex = hue * 7.0;
                int index1 = int(floor(colorIndex));
                int index2 = (index1 + 1) % 7;
                float t = fract(colorIndex);

                vec3 colors[7];
                colors[0] = color1;
                colors[1] = color2;
                colors[2] = color3;
                colors[3] = color4;
                colors[4] = color5;
                colors[5] = color6;
                colors[6] = color7;

                vec3 outlineColor = mix(colors[index1 % 7], colors[index2 % 7], t);
                outlineColor *= 0.65;

                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_color(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    #ifdef FSH
        vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        float fractalShade = fast_fbm(uv + medTime * speed);
        
        vec2 smoothCoord = vec2(gl_FragCoord.xy);
        float baseHue = 0.003 * (smoothCoord.x + smoothCoord.y) - slowTime * speed;
        float hue = mod(baseHue + fractalShade * 3.0, 1.0); // Full fractal influence restored (was 3.0 originally)
        
        float colorIndex = hue * 7.0;
        int index1 = int(floor(colorIndex));
        int index2 = (index1 + 1) % 7;
        float t = fract(colorIndex);
        
        vec3 witchColors[7];
        witchColors[0] = color1;
        witchColors[1] = color2;
        witchColors[2] = color3;
        witchColors[3] = color4;
        witchColors[4] = color5;
        witchColors[5] = color6;
        witchColors[6] = color7;
        
        textData.color.rgb = mix(witchColors[index1 % 7], witchColors[index2 % 7], t);
        
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

// OPTIMIZED: Simplified noxs_veil with 2 octaves
void apply_noxs_veil(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
        float t = medTime * speed;
        vec2 p = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        vec2 q = p * 5.0;
        
        q.x += sin(q.y * 2.0 + t) * 0.2;
        q.y += cos(q.x * 2.0 + t) * 0.2;
        
        float n1 = fast_fbm(q + t);
        float n2 = fast_fbm(q * 1.5 - t * 0.5);
        
        vec3 col = n1 * color1 + n2 * color2;
        col += fast_noise(q * 3.0 + t * 0.25) * color3 * 0.5;
        col += fast_noise(q * 3.0 - t * 0.25) * color4 * 0.5;
        col = pow(col, vec3(1.3));
        
        float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
        star = smoothstep(2.95, 5.0, star) * 0.2;
        textData.color.rgb = col + vec3(star);

        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_sliding_movement(float speed) {
    float t = GameTime * 800.0 * speed;
    
    // Very slow, smooth, large amplitude
    textData.uv.x += sin(t) * 1.5 / 256.0;       // horizontal slide
    textData.uv.y += sin(t * 0.7) * 1.0 / 256.0; // slight vertical
    
    textData.shouldScale = false;
}

void apply_shake_movement(float speed) {
    float t = GameTime * 2000.0 * speed;
    
    // Whole text drifts together slowly
    textData.uv.x += sin(t * 0.7) * 0.35 / 256.0;
    textData.uv.y += sin(t * 0.5) * 0.25 / 256.0;
    
    textData.shouldScale = false;
}

void apply_autumn_leaves(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    #ifdef FSH
        float t = medTime * speed;
        vec2 p = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        vec2 q = p * 5.0;
        
        q.x += sin(q.y * 1.5 + t) * 0.3;
        q.y += cos(q.x * 1.5 + t) * 0.3;
        
        float gradT = 0.05 * (textData.position.x + textData.position.y) - medTime * speed * 10.0;
        float smoothT = fract(gradT / (2.0 * 3.14159)) * 3.0;

        float seg1 = 1.1; // color1 -> color2 boundary
        float seg2 = 1.7; // color2 -> color3 boundary (shorter gap = less time on color3)

        vec3 col;
        if (smoothT < seg1) {
            col = mix(color1, color2, smoothT / seg1);
        } else if (smoothT < seg2) {
            col = mix(color2, color3, (smoothT - seg1) / (seg2 - seg1));
        } else {
            col = mix(color3, color1, (smoothT - seg2) / (3.0 - seg2));
        }

        float n2 = fast_fbm(q * 1.5 - t * 0.2) * 0.7 + 0.3;
        col += (fast_noise(q * 2.0 + t * 0.25) * 0.5 + 0.5) * color4 * 0.4;
        
        float leaf_layer = 0.0;
        for (int i = 0; i < 8; i++) {
            vec2 offset = vec2(sin(t * 0.5 + float(i) * 0.8), cos(t * 0.3 + float(i) * 1.2)) * 3.0;
            vec2 hp = fract(q * 0.5 + offset + vec2(float(i) * 0.3)) - 0.5;
            
            hp.y -= 0.15; // Shift down
            hp *= 8.0; // Scale
            vec2 lp = hp - vec2(0.0, 0.3);
            float ellipse = (lp.x * lp.x) / 0.35 + (lp.y * lp.y) / 0.9;
            float stem = smoothstep(0.0, -0.6, hp.y) * abs(hp.x) * 2.0;
            float leaf = smoothstep(0.1, -0.1, ellipse + stem - 1.0);
            leaf_layer += leaf * (0.5 + 0.5 * sin(t + float(i)));
        }
        
        col += leaf_layer * color5 * 0.6;
        col = clamp(col, vec3(0.2), vec3(1.5)); // Prevent pure black
        col = pow(col, vec3(1.2));
        
        float sparkle = fract(sin(dot(p * 25.0, vec2(12.9898, 78.233))) * 43758.5453);
        sparkle = smoothstep(0.97, 1.0, sparkle) * 0.3;
        
        textData.color.rgb = col + vec3(sparkle);
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_autumn_leaves_outline(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    textData.shouldScale = false;

    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) {
        return; 
    }

    // Thinner outline
    vec2 texelSize = 0.26 / vec2(64.0);

    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float gradT = 0.05 * (textData.position.x + textData.position.y) - medTime * speed * 10.0;
                float smoothT = fract(gradT / (2.0 * 3.14159)) * 3.0;

                float seg1 = 1.1;
                float seg2 = 1.7;

                vec3 col;
                if (smoothT < seg1) {
                    col = mix(color1, color2, smoothT / seg1);
                } else if (smoothT < seg2) {
                    col = mix(color2, color3, (smoothT - seg1) / (seg2 - seg1));
                } else {
                    col = mix(color3, color1, (smoothT - seg2) / (3.0 - seg2));
                }

                vec3 outlineColor = col * 0.55;

                if(textData.isShadow) {
                    outlineColor *= 0.25;
                }

                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

// Valentine's themed shader with floating hearts
void apply_heart(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
        float t = medTime * speed;
        vec2 p = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        vec2 q = p * 5.0;
        
        // Gentle swirling motion
        q.x += sin(q.y * 1.5 + t) * 0.3;
        q.y += cos(q.x * 1.5 + t) * 0.3;
        
        // Base gradient layers with minimum brightness
        float n1 = fast_fbm(q + t * 0.3) * 0.7 + 0.3;
        float n2 = fast_fbm(q * 1.5 - t * 0.2) * 0.7 + 0.3;
        
        vec3 col = n1 * color1 + n2 * color2;
        col += (fast_noise(q * 2.0 + t * 0.25) * 0.5 + 0.5) * color3 * 0.4;
        
        // Heart shape function
        float heart_layer = 0.0;
        for (int i = 0; i < 8; i++) {
            vec2 offset = vec2(sin(t * 0.5 + float(i) * 0.8), cos(t * 0.3 + float(i) * 1.2)) * 3.0;
            vec2 hp = fract(q * 0.5 + offset + vec2(float(i) * 0.3)) - 0.5;
            
            // Heart equation: (x^2 + y^2 - 1)^3 - x^2*y^3 = 0
            hp.y -= 0.15; // Shift down
            hp *= 8.0; // Scale
            float heart = pow(hp.x * hp.x + hp.y * hp.y - 1.0, 3.0) - hp.x * hp.x * hp.y * hp.y * hp.y;
            heart = smoothstep(0.1, -0.1, heart);
            heart_layer += heart * (0.5 + 0.5 * sin(t + float(i)));
        }
        
        // Mix hearts into the colors
        col += heart_layer * color4 * 0.6;
        col = clamp(col, vec3(0.2), vec3(1.5)); // Prevent pure black
        col = pow(col, vec3(1.2));
        
        // Sparkles
        float sparkle = fract(sin(dot(p * 25.0, vec2(12.9898, 78.233))) * 43758.5453);
        sparkle = smoothstep(0.97, 1.0, sparkle) * 0.3;
        
        textData.color.rgb = col + vec3(sparkle);
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

// Valentine's rose petals - falling petals on pink background
void apply_rose_petals(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
        float t = medTime * speed;
        vec2 p = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        vec2 q = p * 5.0;
        
        // Pink background gradient
        float n1 = fast_fbm(q + t * 0.2) * 0.7 + 0.3;
        float n2 = fast_fbm(q * 1.5 - t * 0.15) * 0.7 + 0.3;
        
        vec3 col = n1 * color1 + n2 * color1;
        
        // Rose petal layer
        float total_petal = 0.0;
        vec3 petal_color = vec3(0.0);
        
        for (int i = 0; i < 8; i++) {
            float fi = float(i);
            
            // Falling motion - vertical only
            vec2 offset = vec2(fi * 1.5, t * 0.5 + fi * 1.2);
            vec2 pp = fract(q * 0.5 + offset) - 0.5;
            
            // Gentle sway side to side as they fall
            pp.x += sin(t * 0.8 + fi * 2.0) * 0.1;
            
            // Rotation for tumbling
            float angle = t * 0.4 + fi * 2.0;
            float c = cos(angle);
            float s = sin(angle);
            pp = vec2(pp.x * c - pp.y * s, pp.x * s + pp.y * c);
            
            // Petal shape (elongated oval) - slightly smaller
            pp *= 10.0; // Increased from 8.0 to make petals smaller
            pp.y *= 1.6; // Make it petal-shaped
            float petal = smoothstep(1.5, 0.5, length(pp));
            
            // Pick a red color for this petal
            float color_var = fract(sin(fi * 12.9898) * 43758.5);
            vec3 this_petal_color;
            if (color_var < 0.33) {
                this_petal_color = color2;
            } else if (color_var < 0.66) {
                this_petal_color = color3;
            } else {
                this_petal_color = color4;
            }
            
            total_petal += petal;
            petal_color += petal * this_petal_color;
        }
        
        // Replace background with petal colors where petals exist
        if (total_petal > 0.01) {
            col = mix(col, petal_color / total_petal, min(total_petal, 0.8));
        }
        
        col = clamp(col, vec3(0.2), vec3(1.5));
        col = pow(col, vec3(1.2));
        
        // Sparkles
        float sparkle = fract(sin(dot(p * 25.0, vec2(12.9898, 78.233))) * 43758.5453);
        sparkle = smoothstep(0.97, 1.0, sparkle) * 0.3;
        
        textData.color.rgb = col + vec3(sparkle);
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_noxs_veil_rainbow(float speed) {
    #ifdef FSH
        float t = GameTime * 1200.0 * speed;
        vec2 p = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        vec2 q = p * 5.0;

        q.x += sin(q.y * 2.0 + t) * 0.2;
        q.y += cos(q.x * 2.0 + t) * 0.2;

        float n1 = fast_fbm(q + t);
        float n2 = fast_fbm(q * 1.5 - t * 0.5);
        float n3 = fast_noise(q * 3.0 + t * 0.25);
        float n4 = fast_noise(q * 3.0 - t * 0.25);

        // Extended rainbow color palette for smoother loop
        vec3 rainbowColors[7];
        rainbowColors[0] = vec3(1.0, 0.0, 0.0);     // Red
        rainbowColors[1] = vec3(1.0, 0.5, 0.0);     // Orange
        rainbowColors[2] = vec3(1.0, 1.0, 0.0);     // Yellow
        rainbowColors[3] = vec3(0.0, 1.0, 0.0);     // Green
        rainbowColors[4] = vec3(0.0, 0.5, 1.0);     // Cyan
        rainbowColors[5] = vec3(0.5, 0.0, 1.0);     // Purple
        rainbowColors[6] = vec3(1.0, 0.0, 0.0);     // Red (loop back)

        // Slower time-based rainbow cycling
        float colorTime = GameTime * 150.0 * speed;
        float colorIndex = mod(colorTime, 6.0);
        int idx1 = int(floor(colorIndex));
        int idx2 = idx1 + 1;  // Next color in sequence (includes the looping red)
        float blend = fract(colorIndex);
        blend = smoothstep(0.0, 1.0, blend);

        // Pre-blend the two main colors
        vec3 baseColor = mix(rainbowColors[idx1], rainbowColors[idx2], blend);

        // Normalize noise values to create more visible contrast
        // Use wider range: darker darks and brighter brights
        float contrast1 = n1 * 1.5 - 0.25;  // Range: -0.25 to 1.25
        float contrast2 = n2 * 1.5 - 0.25;
        float contrast3 = n3 * 1.2 - 0.1;
        float contrast4 = n4 * 1.2 - 0.1;

        // Use the blended color for all noise mixing
        vec3 col = contrast1 * baseColor + contrast2 * baseColor;
        col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

        col = clamp(col, 0.0, 1.5);
        col = pow(col, vec3(1.3));

        // Add stars
        float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
        star = smoothstep(2.95, 5.0, star) * 0.2;
        textData.color.rgb = col + vec3(star);
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

float camo_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float camo_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = camo_hash(i);
    float b = camo_hash(i + vec2(1.0, 0.0));
    float c = camo_hash(i + vec2(0.0, 1.0));
    float d = camo_hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float camo_fbm(vec2 p) {
    float total = 0.0;
    float amplitude = 0.6;
    for (int i = 0; i < 4; i++) {
        total += camo_noise(p) * amplitude;
        p *= 1.8;
        amplitude *= 0.5;
    }
    return total;
}

void apply_camo(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 50.0;
        float time = GameTime * 400.0 * speed;
        
        // Create chunky camo blobs
        float n1 = camo_fbm(uv * 2.0 + vec2(time * 0.08, 0.0));
        float n2 = camo_fbm(uv * 1.5 + vec2(100.0, time * 0.06));
        
        // Combine and create sharp transitions
        float pattern = n1 * 0.6 + n2 * 0.4;
        
        // Stretch the pattern to use full range (noise tends to cluster 0.3-0.7)
        pattern = clamp((pattern - 0.3) * 2.0, 0.0, 1.0);
        
        // Even color bands - 25% each
        vec3 color;
        if (pattern < 0.25) {
            color = color4;  // darkest
        } else if (pattern < 0.5) {
            color = color3;
        } else if (pattern < 0.75) {
            color = color2;
        } else {
            color = color1;  // brightest
        }
        
        textData.color.rgb = color;
        
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_camo_outline(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    textData.shouldScale = false;
    
    // Only draw outline if current pixel is transparent
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) {
        return; // Don't draw outline on the character itself
    }
    
    // Thinner outline
    vec2 texelSize = 0.26 / vec2(64.0);
    
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );
    
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                // Sample camo pattern at this position
                vec2 camoUV = vec2(gl_FragCoord.xy) / 50.0;
                float time = GameTime * 400.0 * speed;
                
                float n1 = camo_fbm(camoUV * 2.0 + vec2(time * 0.08, 0.0));
                float n2 = camo_fbm(camoUV * 1.5 + vec2(100.0, time * 0.06));
                
                float pattern = n1 * 0.6 + n2 * 0.4;
                pattern = clamp((pattern - 0.3) * 2.0, 0.0, 1.0);
                
                // Darker versions of the colors for outline
                vec3 darkColor1 = color1 * 0.675;
                vec3 darkColor2 = color2 * 0.675;
                vec3 darkColor3 = color3 * 0.675;
                vec3 darkColor4 = color4 * 0.675;
                
                vec3 outlineColor;
                if (pattern < 0.25) {
                    outlineColor = darkColor4;
                } else if (pattern < 0.5) {
                    outlineColor = darkColor3;
                } else if (pattern < 0.75) {
                    outlineColor = darkColor2;
                } else {
                    outlineColor = darkColor1;
                }
                
                if(textData.isShadow) {
                    outlineColor *= 0.25;
                }
                
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_cycle(vec3 c0, vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, vec3 c6, vec3 c7, float speed, float cycleSpeed) {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 50.0;
        float time = GameTime * 400.0 * speed;

        float n1 = camo_fbm(uv * 1.8 + vec2(time * 0.08, 0.0));
        float n2 = camo_fbm(uv * 1.3 + vec2(100.0, time * 0.06));

        float pattern = n1 * 0.6 + n2 * 0.4;
        pattern = clamp((pattern - 0.3) * 2.0, 0.0, 1.0);

        float band = pattern * 4.0;
        float f = fract(band);
        int idx = int(floor(band));
        float t = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

        vec3 color1[4] = vec3[](c3, c2, c1, c0);
        vec3 color2[4] = vec3[](c7, c6, c5, c4);

        vec3 firCol = mix(color1[clamp(idx, 0, 3)], color1[clamp(idx + 1, 0, 3)], t);
        vec3 watCol = mix(color2[clamp(idx, 0, 3)], color2[clamp(idx + 1, 0, 3)], t);

        float crawlTime = GameTime * cycleSpeed * 500.0;
        float crawlNoise = camo_fbm(uv * 1.5 + vec2(crawlTime * 0.15, crawlTime * 0.08));

        float front = mod(crawlTime, 4.0);
        float normFront = (front / 4.0) * 2.5 - 0.5;

        float edge = smoothstep(normFront - 0.2, normFront + 0.2, crawlNoise);

        float ping = mod(floor(crawlTime / 4.0), 2.0);
        float paletteMix = mix(edge, 1.0 - edge, ping);

        textData.color.rgb = paletteMix > 0.5 ? watCol : firCol;
        if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_cycle_outline(vec3 c0, vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, vec3 c6, vec3 c7, float speed, float cycleSpeed) {
    textData.shouldScale = false;

    // Only draw outline if current pixel is transparent
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) {
        return; // Don't draw outline on the character itself
    }

    // Thinner outline
    vec2 texelSize = 0.26 / vec2(64.0);

    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                // Same pattern/crawl math as apply_camo_cycle, just for outline coloring
                vec2 camoUV = vec2(gl_FragCoord.xy) / 50.0;
                float time = GameTime * 400.0 * speed;

                float n1 = camo_fbm(camoUV * 1.8 + vec2(time * 0.08, 0.0));
                float n2 = camo_fbm(camoUV * 1.3 + vec2(100.0, time * 0.06));

                float pattern = n1 * 0.6 + n2 * 0.4;
                pattern = clamp((pattern - 0.3) * 2.0, 0.0, 1.0);

                float band = pattern * 4.0;
                float f = fract(band);
                int idx = int(floor(band));
                float t = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

                vec3 color1[4] = vec3[](c3, c2, c1, c0);
                vec3 color2[4] = vec3[](c7, c6, c5, c4);

                vec3 firCol = mix(color1[clamp(idx, 0, 3)], color1[clamp(idx + 1, 0, 3)], t);
                vec3 watCol = mix(color2[clamp(idx, 0, 3)], color2[clamp(idx + 1, 0, 3)], t);

                float crawlTime = GameTime * cycleSpeed * 500.0;
                float crawlNoise = camo_fbm(camoUV * 1.5 + vec2(crawlTime * 0.15, crawlTime * 0.08));

                float front = mod(crawlTime, 4.0);
                float normFront = (front / 4.0) * 2.5 - 0.5;

                float edge = smoothstep(normFront - 0.2, normFront + 0.2, crawlNoise);

                float ping = mod(floor(crawlTime / 4.0), 2.0);
                float paletteMix = mix(edge, 1.0 - edge, ping);

                vec3 baseColor = paletteMix > 0.5 ? watCol : firCol;
                vec3 outlineColor = baseColor * 0.5;

                if(textData.isShadow) {
                    outlineColor *= 0.25;
                }

                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_pastel_camo(float speed, float colorSpeed) {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 50.0;
        float time = GameTime * 400.0 * speed;

        float n1 = camo_fbm(uv * 2.0 + vec2(time * 0.08, 0.0));
        float n2 = camo_fbm(uv * 1.5 + vec2(100.0, time * 0.06));

        float pattern = n1 * 0.6 + n2 * 0.4;
        pattern = clamp((pattern - 0.3) * 2.0, 0.0, 1.0);

        // Single hue cycles slowly through pastel spectrum
        float hue = mod(GameTime * 20.0 * colorSpeed, 1.0);
        vec3 baseHue = hsvToRgb(vec3(hue, 0.35, 0.95));

        // 4 shades of that hue: lightest to darkest
        // Mix toward white for light, toward a darker sat version for dark
        vec3 shade1 = mix(baseHue, vec3(1.0), 0.35);          // lightest
        vec3 shade2 = baseHue;                                  // base
        vec3 shade3 = hsvToRgb(vec3(hue, 0.50, 0.78));        // more saturated, darker
        vec3 shade4 = hsvToRgb(vec3(hue, 0.60, 0.60));        // darkest

        vec3 color;
        if (pattern < 0.25) {
            color = shade4;
        } else if (pattern < 0.5) {
            color = shade3;
        } else if (pattern < 0.75) {
            color = shade2;
        } else {
            color = shade1;
        }

        textData.color.rgb = color;

        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_pastel_camo_outline(float speed, float colorSpeed) {
    textData.shouldScale = false;

    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(64.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0),
        vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y),
        vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                vec2 camoUV = vec2(gl_FragCoord.xy) / 50.0;
                float time = GameTime * 400.0 * speed;

                float n1 = camo_fbm(camoUV * 2.0 + vec2(time * 0.08, 0.0));
                float n2 = camo_fbm(camoUV * 1.5 + vec2(100.0, time * 0.06));

                float pattern = n1 * 0.6 + n2 * 0.4;
                pattern = clamp((pattern - 0.3) * 2.0, 0.0, 1.0);

                // Same hue cycle as the fill
                float hue = mod(GameTime * 20.0 * colorSpeed, 1.0);

                // Outline shades: same hue but pushed darker/more saturated
                vec3 shade1 = hsvToRgb(vec3(hue, 0.50, 0.70));
                vec3 shade2 = hsvToRgb(vec3(hue, 0.60, 0.55));
                vec3 shade3 = hsvToRgb(vec3(hue, 0.70, 0.42));
                vec3 shade4 = hsvToRgb(vec3(hue, 0.75, 0.32));

                vec3 outlineColor;
                if (pattern < 0.25) {
                    outlineColor = shade4;
                } else if (pattern < 0.5) {
                    outlineColor = shade3;
                } else if (pattern < 0.75) {
                    outlineColor = shade2;
                } else {
                    outlineColor = shade1;
                }

                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_character_cycle_three_colors(vec3 color1, vec3 color2, vec3 color3, float speed, float frequency) {
    float timeOffset = fastTime * speed;
    float positionOffset = textData.characterPosition.x * frequency;
    float cycle = mod(positionOffset - timeOffset, 3.0);

    vec3 resultColor;
    if (cycle < 1.0) {
        resultColor = mix(color1, color2, cycle);
    } else if (cycle < 2.0) {
        resultColor = mix(color2, color3, cycle - 1.0);
    } else {
        resultColor = mix(color3, color1, cycle - 2.0);
    }

    textData.color.rgb = resultColor;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_character_cycle_four_colors(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed, float frequency) {
    float timeOffset = fastTime * speed;
    float positionOffset = textData.characterPosition.x * frequency;
    float cycle = mod(positionOffset - timeOffset, 4.0);

    vec3 resultColor;
    if (cycle < 1.0) {
        resultColor = mix(color1, color2, cycle);
    } else if (cycle < 2.0) {
        resultColor = mix(color2, color3, cycle - 1.0);
    } else if (cycle < 3.0) {
        resultColor = mix(color3, color4, cycle - 2.0);
    } else {
        resultColor = mix(color4, color1, cycle - 3.0);
    }

    textData.color.rgb = resultColor;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_character_cycle_seven_colors(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed, float frequency) {
    float timeOffset = fastTime * speed;
    float positionOffset = textData.characterPosition.x * frequency;
    float cycle = mod(positionOffset - timeOffset, 7.0);

    vec3 resultColor;
    if (cycle < 1.0) {
        resultColor = mix(color1, color2, cycle);
    } else if (cycle < 2.0) {
        resultColor = mix(color2, color3, cycle - 1.0);
    } else if (cycle < 3.0) {
        resultColor = mix(color3, color4, cycle - 2.0);
    } else if (cycle < 4.0) {
        resultColor = mix(color4, color5, cycle - 3.0);
    } else if (cycle < 5.0) {
        resultColor = mix(color5, color6, cycle - 4.0);
    } else if (cycle < 6.0) {
        resultColor = mix(color6, color7, cycle - 5.0);
    } else {
        resultColor = mix(color7, color1, cycle - 6.0);
    }

    textData.color.rgb = resultColor;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_shimmer(float speed, float intensity) {
    if(textData.isShadow) return;
    float f = textData.localPosition.x + textData.localPosition.y - GameTime * 6400.0 * speed;

    if(mod(f, 5) < 0.75) textData.topColor = vec4(1.0, 1.0, 1.0, intensity);
    textData.shouldScale = true;
}

void apply_color_shimmer(vec3 shimmerColor, float speed, float intensity) {
    if(textData.isShadow) return;
    float f = textData.localPosition.x + textData.localPosition.y - GameTime * 6400.0 * speed;

    if(mod(f, 5) < 0.75) textData.topColor = vec4(shimmerColor, intensity);
    textData.shouldScale = true;
}

void apply_shimmer(){
    apply_shimmer(1.0, 0.5);
    textData.shouldScale = true;
}

float snow_hash(vec2 p) {
    return fract(sin(dot(p, vec2(41.1, 289.7))) * 45758.5453);
}

void apply_snow(float speed, float density, float brightness) {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy);
        float time = GameTime * 1000.0 * speed;
        
        float snow = 0.0;
        
        // Multiple layers of snow for depth
        for (int layer = 0; layer < 3; layer++) {
            float layerScale = 8.0 + float(layer) * 4.0;
            float layerSpeed = 1.0 + float(layer) * 0.3;
            
            vec2 snowUV = uv / layerScale;
            snowUV.y += time * layerSpeed * 0.05;
            snowUV.x += sin(time * 0.02 + float(layer)) * 0.5; // wind sway
            
            vec2 cell = floor(snowUV);
            vec2 local = fract(snowUV);
            
            // Random position within cell
            float randX = snow_hash(cell);
            float randY = snow_hash(cell + vec2(100.0, 0.0));
            
            vec2 snowPos = vec2(randX, randY);
            float dist = length(local - snowPos);
            
            // Snowflake size varies per layer
            float size = 0.15 - float(layer) * 0.03;
            float flake = smoothstep(size, 0.0, dist);
            
            // Fade based on layer (distant = fainter)
            flake *= (1.0 - float(layer) * 0.25);
            
            snow += flake * density;
        }
        
        // Add snow on top of existing color
        vec3 snowColor = vec3(brightness);
        textData.color.rgb = mix(textData.color.rgb, snowColor, snow * 0.8);
        textData.topColor = vec4(snowColor, snow * 0.5);
    #endif
}

void apply_snow() {
    apply_snow(1.0, 1.0, 1.0);
}

// OPTIMIZED: Cache noise calculations
void apply_chromatic_abberation(float speed, float intensity, vec4 color1, vec4 color2) {
    textData.shouldScale = true;
    
    float timeVal = GameTime * 12000.0 * speed;
    float noiseX = noise(timeVal) - 0.5;
    float noiseY = noise(timeVal + 19732.134) - 0.5;
    
    vec2 offset = vec2(0.5 / 128, 0.0) + vec2(0.5, 1.0) * vec2(noiseX, noiseY) / 128 * intensity;
    
    vec2 uv = textData.uv + offset;
    vec4 s1 = texture(Sampler0, uv);
    s1.rgb *= s1.a;
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) s1 = vec4(0.0);
    
    uv = textData.uv - offset;
    vec4 s2 = texture(Sampler0, uv);
    s2.rgb *= s2.a;
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) s2 = vec4(0.0);
    
    textData.backColor = (s1 * color1 * intensity) + (s2 * color2 * intensity);
    textData.backColor.rgb *= textData.color.rgb;
}

void apply_rainbow_abberation(float speed, float intensity) {
    textData.shouldScale = true;

    float timeVal = GameTime * 12000.0 * speed;
    float noiseX = noise(timeVal) - 0.5;
    float noiseY = noise(timeVal + 19732.134) - 0.5;

    vec2 offset = vec2(0.5 / 256, 0.0) + vec2(0.5, 1.0) * vec2(noiseX, noiseY) / 256 * intensity;

    vec4 rainbowColors[7];
    rainbowColors[0] = vec4(1.0, 0.0, 0.0, 1.0);
    rainbowColors[1] = vec4(1.0, 0.5, 0.0, 1.0);
    rainbowColors[2] = vec4(1.0, 1.0, 0.0, 1.0);
    rainbowColors[3] = vec4(0.0, 1.0, 0.0, 1.0);
    rainbowColors[4] = vec4(0.0, 0.0, 1.0, 1.0);
    rainbowColors[5] = vec4(0.3, 0.0, 0.5, 1.0);
    rainbowColors[6] = vec4(0.5, 0.0, 1.0, 1.0);

    int colorIndex1 = int(mod(GameTime * 5.0, 7.0));
    int colorIndex2 = int(mod(colorIndex1 + 3, 7.0));

    vec4 color1 = rainbowColors[colorIndex1];
    vec4 color2 = rainbowColors[colorIndex2];

    vec2 uv = textData.uv + offset;
    vec4 s1 = texture(Sampler0, uv);
    s1.rgb *= s1.a;
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) s1 = vec4(0.0);

    uv = textData.uv - offset;
    vec4 s2 = texture(Sampler0, uv);
    s2.rgb *= s2.a;
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) s2 = vec4(0.0);

    textData.backColor = (s1 * color1 * intensity) + (s2 * color2 * intensity);
    textData.backColor.rgb *= textData.color.rgb;
}

void apply_metalic(vec3 lightColor, vec3 darkColor) {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y > 3) textData.color.rgb = darkColor;
    if(y == 3) textData.color.rgb = lightColor + 0.25;
    if(y < 3) textData.color.rgb = lightColor;

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_metalic(vec3 color) {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y > 3) textData.color.rgb = color * 0.7;
    if(y == 3) textData.color.rgb = color + 0.25;
    if(y < 3) textData.color.rgb = color;

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_fire() {
    textData.shouldScale = false;
    if(textData.isShadow) return;

    float h = fract(textData.uv.y * 256.0);
    vec2 uv = textData.uv + vec2(0.0, 1.0 / 256);
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) return;
    vec4 s = texture(Sampler0, uv);
    if(s.a > 0.1) {
        float f = noise(textData.localPosition * 32.0 + vec2(0.0, GameTime * 6400.0)) * 0.5 + 0.5;
        f -= (1.0 - sqrt(h)) * 0.8;

        if(f > 0.5)
        textData.backColor = vec4(mix(vec3(1.0, 0.2, 0.2), vec3(1.0, 0.7, 0.3), (f - 0.5) / 0.5), 1.0);
    }
}

void apply_hellfire() {
    textData.shouldScale = false;
    if(textData.isShadow) return;

    float h = fract(textData.uv.y * 256.0);
    vec2 uv = textData.uv + vec2(0.0, 1.0 / 256);
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) return;
    vec4 s = texture(Sampler0, uv);
    if(s.a > 0.1) {
        float f = noise(textData.localPosition * 32.0 + vec2(0.0, GameTime * 1600.0)) * 0.5 + 0.5;
        f -= (1.0 - sqrt(h)) * 0.85;

        if(f > 0.5)
        textData.backColor = vec4(mix(vec3(140.0, 20.0, 0.0) / 255.0, vec3(180.0, 20.0, 0.0) / 255.0, (f - 0.5) / 0.5), 1.0);
    }
}

void apply_dark_fire() {
    textData.shouldScale = false;
    if(textData.isShadow) return;

    const int RISE = 5;       
    const float NOISE_SCALE = 14.0; 

    float h = fract(textData.uv.y * 256.0);

    float d = -1.0;
    for(int i = 1; i <= RISE; i++) {
        vec2 uv = textData.uv + vec2(0.0, float(i) / 256.0);
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) break;
        if(texture(Sampler0, uv).a > 0.1) {
            d = float(i) - h;     
            break;
        }
    }
    if(d < 0.0) return;

    float nd = clamp(d / float(RISE), 0.0, 1.0);
    float f = noise(textData.localPosition * NOISE_SCALE + vec2(0.0, GameTime * 6400.0)) * 0.5 + 0.5;
    f -= (1.0 - sqrt(1.0 - nd)) * 0.8;

    if(f > 0.5) {
        textData.backColor = vec4(mix(vec3(40.0, 0.0, 0.0) / 255.0, vec3(160.0, 20.0, 0.0) / 255.0, (f - 0.5) / 0.5), 1.0);
    }
    textData.shouldScale = true;
}

void apply_fade(float speed) {
    textData.color.a = mix(textData.color.a, 0.0, sin(GameTime * 1200 * speed * PI) * 0.5 + 0.5);
}

void apply_fade() {
    apply_fade(1.0);
}

void apply_fade(vec3 color, float speed) {
    if(textData.isShadow) color *= 0.25;

    textData.color.rgb = mix(textData.color.rgb, color, sin(GameTime * 1200 * speed * PI) * 0.5 + 0.5);
}

void apply_fade(vec3 color) {
    apply_fade(color, 1.0);
}

void apply_blinking(float speed){
    if(sin(GameTime * 3200 * speed * PI) < 0.0) { textData.color.a = 0.0; textData.backColor.a = 0.0; textData.topColor.a = 0.0; }
}

void apply_blinking() {
    apply_blinking(0.5);
}

void apply_glowing() {
    if(textData.isShadow) textData.color = vec4(0.0);
    vec3 d = textSdf();
    textData.backColor = vec4(1.0, 1.0, 1.0, (1.0 - d.z) * (1.0 - d.z));
}

void apply_lesbian_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.839, 0.161, 0.000);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.608, 0.333);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.831, 0.384, 0.647);
    if(y >  5) textData.color.rgb = vec3(0.647, 0.000, 0.384);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_mlm_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.000, 0.584, 0.525);
    if(y == 3) textData.color.rgb = vec3(0.412, 0.941, 0.686);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.510, 0.698, 1.000);
    if(y >  5) textData.color.rgb = vec3(0.271, 0.153, 0.627);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_bisexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  4) textData.color.rgb = vec3(0.843, 0.000, 0.443);
    if(y == 4) textData.color.rgb = vec3(0.612, 0.306, 0.592);
    if(y >  4) textData.color.rgb = vec3(0.000, 0.208, 0.663);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_transgender_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.357, 0.812, 0.980);
    if(y == 3) textData.color.rgb = vec3(0.961, 0.671, 0.725);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.961, 0.671, 0.725);
    if(y >  5) textData.color.rgb = vec3(0.357, 0.812, 0.980);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  2) textData.color.rgb = vec3(1.000, 0.012, 0.012);
    if(y == 2) textData.color.rgb = vec3(1.000, 0.549, 0.000);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.929, 0.000);
    if(y == 4) textData.color.rgb = vec3(0.000, 0.502, 0.149);
    if(y == 5) textData.color.rgb = vec3(0.000, 0.302, 1.000);
    if(y >  5) textData.color.rgb = vec3(0.459, 0.027, 0.529);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_pansexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(1.000, 0.129, 0.549);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.847, 0.000);
    if(y == 4) textData.color.rgb = vec3(1.000, 0.847, 0.000);
    if(y >  4) textData.color.rgb = vec3(0.129, 0.694, 1.000);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_asexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.100, 0.100, 0.100);
    if(y == 3) textData.color.rgb = vec3(0.639, 0.639, 0.639);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y >  4) textData.color.rgb = vec3(0.502, 0.000, 0.502);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_aromantic_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.047, 0.655, 0.294);
    if(y == 3) textData.color.rgb = vec3(0.584, 0.796, 0.451);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.639, 0.639, 0.639);
    if(y >  5) textData.color.rgb = vec3(0.100, 0.100, 0.100);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_non_binary_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(1.000, 0.957, 0.173);
    if(y == 3) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 4) textData.color.rgb = vec3(0.616, 0.349, 0.824);
    if(y >  4) textData.color.rgb = vec3(0.100, 0.100, 0.100);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

// Lightweight effect lookup used by the vertex shader.
// Every active FadePack text effect currently requests scaled bounds, so the
// vertex stage only needs to identify whether the marker color maps to an
// effect. Executing the full effect body here duplicated gradient/noise/UV
// work that is only meaningful in the fragment shader.
#define TEXT_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))): if(false)
// Effects that read texCoord0 directly (grid-animated emojis) must NOT get the expanded quad,
// otherwise their texture stretches/flips with it. They opt out of scaling here.
#define TEXT_EFFECT_NOSCALE(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))): textData.shouldScale = false; if(false)

bool hasTextEffect() {
    uint vertexColorId = colorId(floor(round(textData.color.rgb * 255.0) / 4.0) / 255.0);
    if(textData.isShadow) { vertexColorId = colorId(textData.color.rgb); }
    switch(vertexColorId >> 8) {
        case 0xFFFFFFFFu:

    #include <text_effects_config.glsl>

        return true;
    }
    return false;
}

#undef TEXT_EFFECT
#undef TEXT_EFFECT_NOSCALE
#define TEXT_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))):
#define TEXT_EFFECT_NOSCALE(r, g, b) TEXT_EFFECT(r, g, b)

bool applyTextEffects() { 
    uint vertexColorId = colorId(floor(round(textData.color.rgb * 255.0) / 4.0) / 255.0); 
    if(textData.isShadow) { vertexColorId = colorId(textData.color.rgb);} 
    switch(vertexColorId >> 8) { 
        case 0xFFFFFFFFu:

    #include <text_effects_config.glsl>
    
        return true; 
    } 
    return false;
}

#define SPHEYA_PACK_9

#ifdef FSH
layout(location = 6) in vec4 vctfx_screenPos;
layout(location = 7) flat in float vctfx_applyTextEffect;
layout(location = 8) flat in float vctfx_isShadow;
layout(location = 9) flat in float vctfx_changedScale;

layout(location = 10) in vec3 vctfx_ipos1;
layout(location = 11) in vec3 vctfx_ipos2;
layout(location = 12) in vec3 vctfx_ipos3;
layout(location = 13) in vec3 vctfx_ipos4;

layout(location = 14) in vec3 vctfx_uvpos1;
layout(location = 15) in vec3 vctfx_uvpos2;
layout(location = 16) in vec3 vctfx_uvpos3;
layout(location = 17) in vec3 vctfx_uvpos4;

void spheyaAccumulateCorner(vec3 corner, inout vec2 mn, inout vec2 mx) {
    if(corner.z > 1.0e-5) {
        vec2 p = corner.xy / corner.z;
        mn = min(mn, p);
        mx = max(mx, p);
    }
}

bool applySpheyaPack9() {
    if(vctfx_applyTextEffect < 0.5) return false;

    initTimeValues();

    textData.isShadow = vctfx_isShadow > 0.5;
    textData.backColor = vec4(0.0);
    textData.topColor = vec4(0.0);
    textData.doTextureLookup = true;
    textData.color = baseColor;
    
    // Only corners that belong to this triangle have weight > 0; skip the empty slot
    // instead of dividing 0/0. Any 3 corners of the quad span its full bounding box.
    vec2 innerMin = vec2(1.0e30);
    vec2 innerMax = vec2(-1.0e30);
    spheyaAccumulateCorner(vctfx_ipos1, innerMin, innerMax);
    spheyaAccumulateCorner(vctfx_ipos2, innerMin, innerMax);
    spheyaAccumulateCorner(vctfx_ipos3, innerMin, innerMax);
    spheyaAccumulateCorner(vctfx_ipos4, innerMin, innerMax);
    vec2 innerSize = max(innerMax - innerMin, vec2(1.0e-6));

    vec2 uvMin = vec2(1.0e30);
    vec2 uvMax = vec2(-1.0e30);
    spheyaAccumulateCorner(vctfx_uvpos1, uvMin, uvMax);
    spheyaAccumulateCorner(vctfx_uvpos2, uvMin, uvMax);
    spheyaAccumulateCorner(vctfx_uvpos3, uvMin, uvMax);
    spheyaAccumulateCorner(vctfx_uvpos4, uvMin, uvMax);
    vec2 uvSize = uvMax - uvMin;
    textData.uvMin = uvMin;
    textData.uvMax = uvMax;
    textData.uvCenter = uvMin + 0.25 * uvSize;
    textData.localPosition = ((vctfx_screenPos.xy - innerMin) / innerSize);
    textData.localPosition.y = 1.0 - textData.localPosition.y;
    textData.uv = textData.localPosition * uvSize + uvMin;
    if(vctfx_changedScale < 0.5) {
        textData.uv = texCoord0;
    }
    textData.position = vctfx_screenPos.xy * uvSize * 256.0 / innerSize;
    textData.characterPosition = 0.5 * (innerMin + innerMax) * uvSize * 256.0 / innerSize;
#ifdef SPHEYA_SCREENSPACE_FALLBACK
    textData.position = gl_FragCoord.xy * 0.3;
    textData.characterPosition = gl_FragCoord.xy * 0.3;
#endif
    if(textData.isShadow) { 
        textData.characterPosition += vec2(-1.0, 1.0);
        textData.position += vec2(-1.0, 1.0);
    }
    applyTextEffects();
    if(uvBoundsCheck(textData.uv, uvMin, uvMax)) textData.doTextureLookup = false;
    
    vec4 textureSample = texture(Sampler0, textData.uv);

#ifdef RENDERTYPE_TEXT_INTENSITY
    textureSample = textureSample.rrrr;
    textureSample = vec4(0.0);
#endif

    if(!textData.doTextureLookup) textureSample = vec4(0.0);
    textData.topColor.a *= textureSample.a;

    vec4 effectColor = mix(vec4(textData.backColor.rgb, textData.backColor.a * textData.color.a), textureSample * textData.color, textureSample.a);
    effectColor.rgb = mix(effectColor.rgb, textData.topColor.rgb, textData.topColor.a);
    effectColor *= lightColor * ColorModulator;

    if (effectColor.a < 0.1) {
        discard;
    }

#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, effectColor.a);
#else
#ifdef OIT_ACCUMULATE
    effectColor = sampleColorForAccumulation(effectColor);
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#ifdef OIT_ACCUMULATE
    vec4 effectFogColor = vec4(FogColor.rgb * effectColor.a, FogColor.a);
#else
    vec4 effectFogColor = FogColor;
#endif
    fragColor = apply_fog(
        effectColor,
        sphericalVertexDistance,
        cylindricalVertexDistance,
        FogEnvironmentalStart,
        FogEnvironmentalEnd,
        FogRenderDistanceStart,
        FogRenderDistanceEnd,
        effectFogColor
    );
#else
    fragColor = effectColor;
#endif
#endif
    return true;
}

#endif

#ifdef VSH
layout(location = 6) out vec4 vctfx_screenPos;
layout(location = 7) flat out float vctfx_applyTextEffect;
layout(location = 8) flat out float vctfx_isShadow;
layout(location = 9) flat out float vctfx_changedScale;

layout(location = 10) out vec3 vctfx_ipos1;
layout(location = 11) out vec3 vctfx_ipos2;
layout(location = 12) out vec3 vctfx_ipos3;
layout(location = 13) out vec3 vctfx_ipos4;

layout(location = 14) out vec3 vctfx_uvpos1;
layout(location = 15) out vec3 vctfx_uvpos2;
layout(location = 16) out vec3 vctfx_uvpos3;
layout(location = 17) out vec3 vctfx_uvpos4;

bool applySpheyaPack9() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // MC draws shadow text as colour * 0.25; every effect marker colour has r,g >= 240.
    vctfx_isShadow = (max(Color.r, Color.g) < 0.5) ? 1.0 : 0.0;
    vctfx_applyTextEffect = 1.0;
    vctfx_changedScale = 0.0;

    textData.isShadow = vctfx_isShadow > 0.5;
    textData.color = Color;
    textData.shouldScale = true;

    if(!hasTextEffect()) {
        vctfx_isShadow = 0.0;

#ifdef IS_1_21_6
        if (textData.isShadow)
        {
#else
        if(Position.z == 0.0 && textData.isShadow) {
#endif
            textData.isShadow = false;
            if(hasTextEffect()) {
                vctfx_isShadow = 0.0;
            }else {
                vctfx_applyTextEffect = 0.0;
                return false;
            }
        }else{
            vctfx_applyTextEffect = 0.0;
            return false;
        }
    }

    // Effects need the expanded quad unless they opt out via TEXT_EFFECT_NOSCALE.

    vec2 corner = vec2[](vec2(-1.0, +1.0), vec2(-1.0, -1.0), vec2(+1.0, -1.0), vec2(+1.0, +1.0))[gl_VertexIndex % 4];
    if(textureSize(Sampler0, 0) != ivec2(256, 256)) {
        vctfx_applyTextEffect = 0.0;
        return false;
    }

    vctfx_uvpos1 = vctfx_uvpos2 = vctfx_uvpos3 = vctfx_uvpos4 = vctfx_ipos1 = vctfx_ipos2 = vctfx_ipos3 = vctfx_ipos4 = vec3(0.0);
    switch (gl_VertexIndex % 4) {
        case 0: vctfx_ipos1 = vec3(gl_Position.xy, 1.0); vctfx_uvpos1 = vec3(UV0.xy, 1.0); break;
        case 1: vctfx_ipos2 = vec3(gl_Position.xy, 1.0); vctfx_uvpos2 = vec3(UV0.xy, 1.0); break;
        case 2: vctfx_ipos3 = vec3(gl_Position.xy, 1.0); vctfx_uvpos3 = vec3(UV0.xy, 1.0); break;
        case 3: vctfx_ipos4 = vec3(gl_Position.xy, 1.0); vctfx_uvpos4 = vec3(UV0.xy, 1.0); break;
    } 

#ifdef SPHEYA_SCREENSPACE_FALLBACK
    if(false && textData.shouldScale) {
#else
    if(textData.shouldScale) {
#endif
        gl_Position.xy += corner * 0.02;
        vctfx_changedScale = 1.0;
    }

    vctfx_screenPos = gl_Position;
#ifdef IS_1_21_6
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#endif
#else
    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
#endif
    vertexColor = baseColor * lightColor;
    texCoord0 = UV0;
    return true;
}

#endif

#endif
