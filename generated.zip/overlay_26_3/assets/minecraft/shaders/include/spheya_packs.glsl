#include <text_effects.glsl>
#include <remove_scoreboard_numbers.glsl>