// Player skin animation implementations only.
// RGB -> effect selection is kept in skin_effects_config.glsl.

#define SKINFX_ALPHA 173
#define FX_RAINBOW 1
#define FX_VOID 2
#define FX_GLITCH 3
#define FX_ENCHANTED 4
#define FX_HOLOGRAM 5
#define FX_AURORA 6
#define FX_INFERNO 7
#define FX_FROST 8
#define FX_GALAXY 9
#define FX_MOLTEN 10
#define FX_MIDAS 11
#define FX_TOXIC 12
#define FX_STORM 13
#define FX_PRISM 15
#define FX_HALLOWEEN 19
#define FX_BLOOD_MOON 20
#define FX_BLACK_HOLE 21
#define FXF_EMISSIVE 1
#define FXF_HURT 2
#define FXF_KEY 4
#define SKINFX_TAU 6.2831853

uniform float GameTime;

ivec4 skinfx_px(sampler2D tex, int x) {
    return ivec4(round(texelFetch(tex, ivec2(x, 0), 0) * 255.0));
}

void skinfx_detect(sampler2D tex, out ivec4 effect, out ivec4 effect2, out vec3 colorA, out vec3 colorB, out vec4 key) {
    effect = ivec4(0);
    effect2 = ivec4(0);
    colorA = vec3(0.0);
    colorB = vec3(0.0);
    key = vec4(0.0);
    if(textureSize(tex, 0) != ivec2(64, 64)) return;
    if(skinfx_px(tex, 32).rgb != ivec3(19, 84, 201) || skinfx_px(tex, 32).a != 0) return;
    if(skinfx_px(tex, 33).rgb != ivec3(201, 84, 19) || skinfx_px(tex, 33).a != 0) return;
    ivec4 version = skinfx_px(tex, 39);
    ivec4 first = skinfx_px(tex, 34);
    if(version.r != 1 || version.a != 0 || first.a != 0) return;
    colorA = vec3(skinfx_px(tex, 35).rgb) / 255.0;
    colorB = vec3(skinfx_px(tex, 36).rgb) / 255.0;
    ivec4 k = skinfx_px(tex, 37);
    if(k.a == 0) key = vec4(vec3(k.rgb) / 255.0, 1.0);
}

vec3 skinfx_rgb(int r, int g, int b) {
    return vec3(float(r), float(g), float(b)) / 255.0;
}

bool skinfx_rgb_match(vec3 a, vec3 b) {
    return all(lessThanEqual(abs(a - b), vec3(0.004)));
}

float skinfx_time(int speed) {
    return GameTime * float(speed) * SKINFX_TAU;
}

float skinfx_phase(int speed, float base) {
    return skinfx_time(speed) / SKINFX_TAU;
}

float skinfx_hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float skinfx_noise(vec2 p, float period) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float y0 = i.y;
    float y1 = i.y + 1.0;
    if(period > 0.0) {
        y0 = mod(y0, period);
        y1 = mod(y1, period);
    }
    float a = skinfx_hash(vec2(i.x, y0));
    float b = skinfx_hash(vec2(i.x + 1.0, y0));
    float c = skinfx_hash(vec2(i.x, y1));
    float d = skinfx_hash(vec2(i.x + 1.0, y1));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float skinfx_fbm(vec2 p, float period) {
    return 0.65 * skinfx_noise(p, period) + 0.35 * skinfx_noise(p * 2.0 + vec2(17.0, 0.0), period * 2.0);
}

vec3 skinfx_hue(float h) {
    return clamp(abs(fract(h + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
}

float skinfx_luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

vec3 skinfx_move_one(ivec4 e, vec3 pos) {
    float k = float(e.z) / 255.0;


    return vec3(0.0);
}

vec3 skinfx_move(ivec4 effect, ivec4 effect2, vec3 pos) {
    if(effect.x == 0) return pos;
    return pos + skinfx_move_one(effect, pos) + skinfx_move_one(effect2, pos);
}

#ifdef SKINFX_FRAGMENT
bool skinfx_is_key(vec3 c, vec4 key) {
    return key.a > 0.5 && all(equal(ivec3(round(c * 255.0)), ivec3(round(key.rgb * 255.0))));
}

float skinfx_star(vec2 uv, float t, float rarity) {
    float h = skinfx_hash(floor(uv * 64.0));
    if(h < rarity) return 0.0;
    vec2 f = fract(uv * 64.0) - 0.5;
    float shape = max(0.0, 1.0 - (abs(f.x) + abs(f.y)) * 3.2);
    float life = pow(max(0.0, sin(t + h * 97.0)), 16.0);
    return shape * shape * life;
}

vec4 skinfx_glitch(sampler2D tex, vec2 uv, vec4 color, int speed, int intensity) {
    float k = float(intensity) / 255.0;
    float t = skinfx_phase(speed, 180.0);
    float moment = floor(t * 32.0);
    float burst = step(0.62, skinfx_hash(vec2(moment, 7.0)));
    if(burst < 0.5) return color;
    float row = floor(uv.y * 64.0 / 2.0);
    float shift = (skinfx_hash(vec2(row, moment)) - 0.5) * 6.0 / 64.0 * k;
    float split = (1.0 + 2.0 * k) / 64.0;
    vec4 moved = texture(tex, uv + vec2(shift, 0.0));
    vec3 rgb = moved.a > 0.1 ? moved.rgb : color.rgb;
    vec4 r = texture(tex, uv + vec2(shift + split, 0.0));
    vec4 b = texture(tex, uv + vec2(shift - split, 0.0));
    if(r.a > 0.1) rgb.r = r.r;
    if(b.a > 0.1) rgb.b = b.b;
    return vec4(rgb, color.a);
}

float skinfx_cracks(vec2 p) {
    vec2 cell = floor(p);
    float d1 = 8.0;
    float d2 = 8.0;
    for(int y = -1; y <= 1; y++) {
        for(int x = -1; x <= 1; x++) {
            vec2 c = cell + vec2(float(x), float(y));
            vec2 point = c + vec2(skinfx_hash(c), skinfx_hash(c + 31.0));
            float d = length(point - p);
            if(d < d1) {
                d2 = d1;
                d1 = d;
            } else if(d < d2) {
                d2 = d;
            }
        }
    }
    return 1.0 - smoothstep(0.02, 0.09, d2 - d1);
}



vec3 skinfx_recolor(int id, int speed, int intensity, vec3 c, vec2 uv, vec3 tint) {
    float k = float(intensity) / 255.0;
    float l = skinfx_luma(c);
    float t = skinfx_time(speed);

    if(id == FX_RAINBOW) {
        vec3 rainbow = skinfx_hue(t / SKINFX_TAU + uv.y * 1.6 + uv.x * 0.6);
        return mix(c, c * (0.72 + 0.55 * rainbow), 0.55 * k);
    }
    if(id == FX_VOID) {
        float flow = 0.5 + 0.5 * sin((uv.x * 5.0 - uv.y * 3.5) * SKINFX_TAU + sin(t) * 1.2);
        float wave = pow(0.5 + 0.5 * sin(uv.x * 9.0 + uv.y * 5.0 + cos(t) * 1.7), 5.0);
        vec3 purple = vec3(0.28, 0.055, 0.58);
        float amount = (0.018 + flow * 0.025 + wave * 0.018) * k;
        return mix(c, c + purple * (0.3 + 0.7 * l), amount);
    }
    if(id == FX_HOLOGRAM) {
        float scan = 0.5 + 0.5 * sin(uv.y * 42.0 - sin(t) * 2.0);
        float sweepPos = 0.5 + 0.5 * sin(t * 0.35);
        float sweep = exp(-pow((uv.x + uv.y * 0.35 - sweepPos) * 5.0, 2.0));
        vec3 holo = tint * (0.12 + scan * 0.08 + sweep * 0.4);
        return mix(c, c + holo * (0.5 + 0.5 * l), 0.28 * k);
    }
    if(id == FX_ENCHANTED) {
        float band = 0.5 + 0.5 * sin((uv.x * 1.25 + uv.y * 0.9) * SKINFX_TAU * 2.0 - t * 0.9);
        float glow = smoothstep(0.62, 0.96, band);
        float stars = skinfx_star(uv, t * 0.55, 0.975);
        vec3 magic = mix(vec3(0.32, 0.08, 1.0), vec3(0.95, 0.15, 0.85), band);
        return mix(c, c + magic * (glow * 0.28 + stars * 0.34), 0.9 * k);
    }
    if(id == FX_AURORA) {
        float drift = sin(t * 0.22);
        float wave1 = 0.5 + 0.5 * sin(uv.x * 9.0 + sin(uv.y * 5.0 + t * 0.35) * 2.8 - t * 0.42);
        float wave2 = 0.5 + 0.5 * sin(uv.x * 15.0 - uv.y * 6.0 + t * 0.28);
        float band = smoothstep(0.5, 0.88, wave1 * 0.72 + wave2 * 0.28);
        vec3 aurora = mix(vec3(0.05, 1.0, 0.42), vec3(0.2, 0.72, 1.0), 0.5 + 0.5 * sin(t * 0.12 + uv.x * 4.0 + drift));
        return mix(c, c + aurora * band * (0.28 + 0.18 * l), 0.8 * k);
    }
    if(id == FX_INFERNO) {
        vec2 flow = vec2(sin(t * 0.18), cos(t * 0.18));
        float n = skinfx_fbm(uv * 9.0 + flow * 1.8 + vec2(0.0, uv.y * 3.0), 10.0);
        float flame = smoothstep(0.48, 0.86, n);
        vec3 fire = mix(vec3(1.0, 0.12, 0.01), vec3(1.0, 0.78, 0.08), n);
        return mix(c, c + fire * flame * 0.3, 0.76 * k);
    }
    if(id == FX_FROST) {
        float sheen = pow(0.5 + 0.5 * sin((uv.x + uv.y) * 7.0 - t * 0.8), 12.0);
        vec3 ice = mix(vec3(0.45, 0.68, 1.0) * (0.35 + l), vec3(0.88, 0.96, 1.0), smoothstep(0.5, 0.95, l));
        return mix(c, ice + vec3(0.75,0.9,1.0) * sheen * 0.12, 0.55 * k);
    }
    if(id == FX_GALAXY) {
        vec2 drift = vec2(cos(t * 0.18), sin(t * 0.18));
        float n = skinfx_fbm(uv * 6.0 + drift * 0.8, 0.0);
        vec2 drift2 = vec2(sin(t * 0.23), cos(t * 0.23));
        float m = skinfx_noise(uv * 4.0 + drift2 * 0.6 + 40.0, 0.0);
        vec3 nebula = mix(mix(vec3(0.25, 0.08, 0.75), vec3(0.95, 0.25, 0.7), m), vec3(0.2, 0.55, 1.0), smoothstep(0.55, 0.9, n)) * smoothstep(0.2, 0.75, n) * 0.55;
        return mix(c, c + nebula, 0.7 * k);
    }
    if(id == FX_MOLTEN) {
        float crack = skinfx_cracks(uv * vec2(9.0, 7.0) + vec2(sin(t * 0.18), cos(t * 0.18)) * 0.25);
        float heat = 0.5 + 0.5 * sin(t * 0.7 + uv.x * 9.0 - uv.y * 12.0);
        vec3 lava = vec3(1.0, 0.18, 0.01) * (0.45 + 0.65 * heat);
        return mix(c, c + lava * crack * 0.42, 0.72 * k);
    }
    if(id == FX_MIDAS) {
        float sweep = 0.5 + 0.5 * sin((uv.x * 1.2 - uv.y) * SKINFX_TAU * 1.2 - t * 0.55);
        float shine = pow(sweep, 12.0);
        return mix(c, c + vec3(1.0, 0.72, 0.08) * shine * 0.36, 0.82 * k);
    }
    if(id == FX_TOXIC) {
        vec2 drift = vec2(sin(t * 0.2), cos(t * 0.2));
        float flow = skinfx_fbm(uv * 10.0 + drift * 1.2, 12.0);
        vec2 bubbleDrift = vec2(cos(t * 0.27), sin(t * 0.27));
        float bubbles = smoothstep(0.7, 0.9, skinfx_noise(uv * 18.0 + bubbleDrift * 0.9, 18.0));
        vec3 toxic = vec3(0.12, 1.0, 0.22) * (flow * 0.2 + bubbles * 0.38);
        return mix(c, c + toxic, 0.9 * k);
    }
    if(id == FX_STORM) {
        float bolt = pow(max(0.0, sin(uv.x * 13.0 + sin(uv.y * 11.0 + t * 0.7) * 2.5 + t * 0.95)), 18.0);
        float wave = pow(0.5 + 0.5 * sin(uv.y * 9.0 - t * 0.55), 7.0);
        vec3 lightning = vec3(0.35, 0.72, 1.0) * (bolt * 0.5 + wave * 0.08);
        return mix(c, c + lightning, 0.86 * k);
    }
    if(id == FX_PRISM) {
        float wave = 0.5 + 0.5 * sin((uv.x * 0.9 - uv.y * 0.65) * SKINFX_TAU * 1.05 - t * 0.7);
        float hue = t / SKINFX_TAU * 0.18 + uv.x * 0.35 + uv.y * 0.18 + wave * 0.12;
        vec3 prism = skinfx_hue(hue);
        float sheen = pow(0.5 + 0.5 * sin(hue * SKINFX_TAU * 2.0 - t * 0.22), 7.0);
        return mix(c, c + prism * (0.16 + sheen * 0.16), 0.76 * k);
    }
    if(id == FX_HALLOWEEN) {
        vec2 drift = vec2(sin(t * 0.2), cos(t * 0.2));
        float n = skinfx_fbm(uv * 8.0 + drift * 1.5, 10.0);
        float flame = smoothstep(0.5, 0.86, n);
        vec2 emberDrift = vec2(cos(t * 0.26), sin(t * 0.26));
        float ember = smoothstep(0.68, 0.9, skinfx_noise(uv * 17.0 + emberDrift, 17.0));
        vec3 orange = mix(vec3(1.0, 0.12, 0.01), vec3(1.0, 0.72, 0.08), n);
        return mix(c, c + orange * (flame * 0.26 + ember * 0.14), 0.84 * k);
    }
    if(id == FX_BLOOD_MOON) {
        float sweepPos = 0.5 + 0.85 * sin(t * 0.5);
        float linePos = uv.x + uv.y * 0.28;
        float sweep = exp(-pow((linePos - sweepPos) * 11.0, 2.0));
        float sweepSoft = exp(-pow((linePos - sweepPos) * 4.5, 2.0));
        vec3 blood = vec3(1.0, 0.012, 0.028);
        return c + blood * (sweep * 0.16 + sweepSoft * 0.035) * k;
    }
    if(id == FX_BLACK_HOLE) {
        vec2 p = uv - 0.5;
        float r = length(p);
        float a = atan(p.y, p.x);
        float spiralA = a + r * 20.0 - sin(t * 0.4) * 1.25;
        float spiralB = a - r * 14.0 + cos(t * 0.32) * 0.85;
        float bandA = pow(0.5 + 0.5 * sin(spiralA * 3.0), 7.0);
        float bandB = pow(0.5 + 0.5 * sin(spiralB * 4.0), 10.0);
        float edge = smoothstep(0.08, 0.42, r) * (1.0 - smoothstep(0.38, 0.7, r));
        vec3 ring = vec3(0.42, 0.025, 0.95) * bandA * 0.32 + vec3(0.04, 0.22, 1.0) * bandB * 0.22;
        return mix(c, c + ring * edge, 0.68 * k);
    }
    return c;
}

vec3 skinfx_glow(int id, int speed, int intensity, vec2 uv, vec3 tint, vec3 c, vec2 fc) {
    float k = float(intensity) / 255.0;
    float t = skinfx_time(speed);

    if(id == FX_ENCHANTED) {
        float band = pow(max(0.0, 0.5 + 0.5 * sin((uv.x * 1.25 + uv.y * 0.9) * SKINFX_TAU * 2.0 - t * 0.9)), 8.0);
        float star = skinfx_star(uv, t * 0.55, 0.975);
        return (vec3(0.42, 0.08, 1.0) * band * 0.34 + vec3(1.0, 0.45, 0.95) * star * 0.85) * k;
    }
    if(id == FX_VOID) {
        float star = skinfx_star(uv, t * 0.45, 0.95);
        float wave = pow(0.5 + 0.5 * sin(uv.x * 12.0 - uv.y * 7.0 + sin(t * 0.4)), 10.0);
        return (vec3(0.55, 0.15, 1.0) * (star * 0.55 + wave * 0.05)) * k;
    }
    if(id == FX_HOLOGRAM) {
        float scan = 0.5 + 0.5 * sin(uv.y * 42.0 - sin(t * 0.5) * 2.0);
        float sweepPos = 0.5 + 0.5 * sin(t * 0.35);
        float sweep = exp(-pow((uv.x + uv.y * 0.35 - sweepPos) * 5.0, 2.0));
        return tint * (scan * 0.08 + sweep * 0.55) * k;
    }
    if(id == FX_RAINBOW) {
        float shine = pow(0.5 + 0.5 * sin((uv.x + uv.y) * 14.0 - t), 12.0);
        return skinfx_hue(t / SKINFX_TAU + uv.y) * shine * 0.3 * k;
    }
    if(id == FX_AURORA) {
        float wave = 0.5 + 0.5 * sin(uv.x * 12.0 + sin(uv.y * 8.0 + t * 0.3) * 2.5 - t * 0.5);
        float band = pow(smoothstep(0.58, 0.9, wave), 1.2);
        vec3 col = mix(vec3(0.05, 1.0, 0.45), vec3(0.2, 0.7, 1.0), 0.5 + 0.5 * sin(t * 0.12 + uv.x * 5.0));
        return col * band * 0.5 * k;
    }
    if(id == FX_INFERNO) {
        vec2 flow = vec2(sin(t * 0.18), cos(t * 0.18));
        float n = skinfx_fbm(uv * 12.0 + flow * 1.3, 10.0);
        float flame = smoothstep(0.58, 0.9, n);
        vec3 col = mix(vec3(1.0, 0.08, 0.0), vec3(1.0, 0.8, 0.08), n);
        return col * flame * 0.7 * k;
    }
    if(id == FX_FROST) {
        float sheen = pow(0.5 + 0.5 * sin((uv.x + uv.y) * 6.0 - t * 0.7), 14.0);
        return vec3(0.75, 0.9, 1.0) * sheen * 0.55 * k;
    }
    if(id == FX_GALAXY) return vec3(0.9, 0.9, 1.0) * skinfx_star(uv, t * 0.8, 0.94) * 1.0 * k;
    if(id == FX_MOLTEN) {
        float crack = skinfx_cracks(uv * vec2(9.0, 7.0) + vec2(sin(t * 0.18), cos(t * 0.18)) * 0.25);
        float heat = 0.5 + 0.5 * sin(t * 0.7 + uv.x * 9.0 - uv.y * 12.0);
        return vec3(1.0, 0.2, 0.01) * crack * (0.3 + 0.6 * heat) * 0.8 * k;
    }
    if(id == FX_MIDAS) {
        float sweep = 0.5 + 0.5 * sin((uv.x * 1.2 - uv.y) * SKINFX_TAU * 1.2 - t * 0.55);
        float shine = pow(sweep, 16.0);
        return vec3(1.0, 0.85, 0.35) * shine * 0.7 * k;
    }
    if(id == FX_TOXIC) {
        vec2 drift = vec2(cos(t * 0.27), sin(t * 0.27));
        float bubbles = smoothstep(0.72, 0.93, skinfx_noise(uv * 18.0 + drift * 0.9, 18.0));
        float flow = pow(0.5 + 0.5 * sin(uv.x * 11.0 - uv.y * 8.0 + t * 0.6), 8.0);
        return vec3(0.2, 1.0, 0.25) * (bubbles * 0.55 + flow * 0.12) * k;
    }
    if(id == FX_STORM) {
        float bolt = pow(max(0.0, sin(uv.x * 13.0 + sin(uv.y * 11.0 + t * 0.7) * 2.5 + t * 0.95)), 18.0);
        float flash = pow(0.5 + 0.5 * sin(t * 0.6), 10.0);
        return vec3(0.35, 0.75, 1.0) * (bolt * 0.8 + flash * 0.12) * k;
    }
    if(id == FX_PRISM) {
        float hue = t / SKINFX_TAU * 0.18 + uv.x * 0.35 + uv.y * 0.18;
        float shine = pow(0.5 + 0.5 * sin(hue * SKINFX_TAU * 2.0 - t * 0.22), 8.0);
        return vec3(1.0) * shine * 0.34 * k;
    }
    if(id == FX_HALLOWEEN) {
        vec2 drift = vec2(sin(t * 0.2), cos(t * 0.2));
        float n = skinfx_fbm(uv * 8.0 + drift * 1.5, 10.0);
        float flame = smoothstep(0.55, 0.88, n);
        vec3 orange = mix(vec3(1.0, 0.12, 0.01), vec3(1.0, 0.7, 0.08), n);
        return orange * flame * 0.62 * k;
    }
    if(id == FX_BLOOD_MOON) {
        float sweepPos = 0.5 + 0.85 * sin(t * 0.5);
        float linePos = uv.x + uv.y * 0.28;
        float sweep = exp(-pow((linePos - sweepPos) * 11.0, 2.0));
        float sweepSoft = exp(-pow((linePos - sweepPos) * 4.5, 2.0));
        return vec3(1.0, 0.012, 0.028) * (sweep * 0.7 + sweepSoft * 0.15) * k;
    }
    if(id == FX_BLACK_HOLE) {
        vec2 p = uv - 0.5;
        float r = length(p);
        float a = atan(p.y, p.x);
        float s1 = pow(0.5 + 0.5 * sin((a + r * 20.0 - sin(t * 0.4) * 1.25) * 3.0), 10.0);
        float s2 = pow(0.5 + 0.5 * sin((a - r * 14.0 + cos(t * 0.32) * 0.85) * 4.0), 12.0);
        float edge = smoothstep(0.08, 0.42, r) * (1.0 - smoothstep(0.38, 0.7, r));
        return (vec3(0.58, 0.05, 1.0) * s1 * 0.65 + vec3(0.08, 0.3, 1.0) * s2 * 0.45) * edge * k;
    }
    return vec3(0.0);
}

float skinfx_alpha(int id, int speed, int intensity) {
    if(id != FX_HOLOGRAM) return 1.0;
    return mix(1.0, 0.62, float(intensity) / 255.0);
}
#endif
