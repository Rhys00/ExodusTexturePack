ExodusMC - Alien Incubator (ItemsAdder static furniture) v2

INSTALL
1. Copy the "exodus_incubator" folder into:
   plugins/ItemsAdder/contents/
   Replace the previous exodus_incubator folder if you already installed v1.

2. Run your normal ItemsAdder resource-pack regeneration command (for example /iazip).

3. Get the furniture with:
   /iaget exodus_incubator:alien_incubator

V2 ADJUSTMENTS
- Doubled furniture visual scale to 2.0x.
- Raised display translation by 0.85 blocks so it sits above the placement floor.
- Expanded hitbox to 3x3x3, the documented maximum for ItemsAdder furniture.
- Added render_size 4x4 for the larger ItemDisplay model.
- Enabled auto_update_in_world for display transformations on supported ItemsAdder versions.

NOTE
If an already-placed v1 furniture does not visually update after reload, break it and place a new copy after regenerating/reloading the pack.


V3 changes:
- Increased display scale from 2.0 to 2.25
- Raised display translation from 0.85 to 0.95
- Moved the green egg geometry left/back so it sits inside the incubator chamber
- Increased render size and hitbox for the larger placement
