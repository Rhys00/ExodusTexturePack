TEXT_EFFECT(240, 236, 4) { // #f0ec04
    apply_rainbow_fractal();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 0) { // #f0f000
    apply_pale_rainbow_fractal();
    apply_pastel_outline();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 4) { // #f0f004
    apply_pastel_rainbow();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 8) { //#f0f008
    apply_rainbow();
    textData.shouldScale = true;
}


TEXT_EFFECT(240, 240, 12) { // #f0f00c
    apply_ocean_rainbow(4.0); 
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,20) { // #f0f014 blue
    apply_ocean(rgb(0, 230, 118), rgb(76, 205, 245), rgb(224, 84, 229), rgb(136, 59, 252), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,24) { // #f0f018 green
    apply_ocean(rgb(200, 255, 200), rgb(80, 255, 80), rgb(20, 160, 20), rgb(0, 40, 0), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,28) { // #f0f01c red
    apply_ocean(rgb(255, 0, 0), rgb(255, 80, 80), rgb(160, 20, 20), rgb(40, 0, 0), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,32) { // #f0f020 purple
    apply_ocean(rgb(235,210,255), rgb(180,90,255), rgb(110,30,160), rgb(35,0,55), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,36) {
    apply_character_cycle_seven_colors(rgb(252, 141, 53), rgb(236, 82, 79), rgb(252, 141, 53), rgb(252, 200, 39), rgb(203, 201, 70), rgb(154, 202, 100), rgb(38, 196, 215), 10, 0.15);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,40) { // snap test #f0f028
    apply_ocean(rgb(255,255,255), rgb(200,200,200), rgb(25,25,25), rgb(55,55,55), 1.5);
    apply_shimmer();
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,44) { // #f0f02c
    apply_binary(rgb(0,0,0), rgb(0,255,0), 5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,48) { // #f0f030
    apply_quicksilver(rgb(255,209,220), rgb(255,218,185), rgb(253,253,150), rgb(184,242,230), rgb(174,198,207), rgb(205,180,219), rgb(255,255,255), 500.0);
    textData.shouldScale = true;
}


TEXT_EFFECT(240,240,52) { // #f0f034
    apply_fractal_color(rgb(255, 105, 180), rgb(255, 20, 147), rgb(255, 182, 193), rgb(218, 112, 214), rgb(186, 85, 211), rgb(238, 130, 238), rgb(128, 0, 128), 0.4);
    textData.shouldScale = true;
}


TEXT_EFFECT(240,240,56) {  // Spectrum #f0f038 join message
    apply_rainbow_fractal();
    apply_waving_movement();
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,60) {  // Spectrum #f0f03c set cosmetic
    apply_rainbow_fractal();
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,64) {  // #f0f040 Glitched join message
    override_text_color(rgb(255,255,255));
    apply_chromatic_abberation(1.0, 2.0, vec4(1.0, 1.0, 1.0, 1.0), vec4(0.0, 0.0, 0.0, 0.0));
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,68) {  // galactic #f0f044 set / part 1 of join message
    apply_ocean(rgb(16, 12, 236), rgb(98, 21, 243), rgb(146, 64, 240), rgb(195, 48, 253), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,72) {  // galactic star #f0f048 part 2 join message
    apply_animated_gradient_7(rgb(255, 162, 0), rgb(215, 155, 35), rgb(255, 205, 55), rgb(255, 235, 120), rgb(255, 248, 185), rgb(255, 255, 255), rgb(245, 180, 40), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,76) {  // Inferno #f0f04c join / set 
    override_text_color(rgb(255, 20, 20));
    apply_fire();
    apply_fade(rgb(238, 121, 12));
    textData.shouldScale = true;
}


TEXT_EFFECT(240,240,80) {  // royal #f0f050 set / join
    apply_animated_gradient_7(rgb(255, 162, 0), rgb(215, 155, 35), rgb(255, 205, 55), rgb(255, 235, 120), rgb(255, 248, 185), rgb(255, 255, 255), rgb(245, 180, 40), 1.5);
    textData.shouldScale = true;
}


TEXT_EFFECT(240,240,84) {  // Royal Blue
    apply_animated_gradient_7(
        rgb(8, 20, 70),      // Deep Navy
        rgb(20, 45, 125),    // Dark Royal Blue
        rgb(45, 85, 215),    // Royal Blue
        rgb(95, 165, 255),   // Bright Sapphire
        rgb(40, 43, 238),  // Soft Ice Blue
        rgb(4, 27, 156),  // White Highlight
        rgb(25, 55, 170),    // Rich Blue
        1.0
    );
    textData.shouldScale = true;
}



TEXT_EFFECT(240,240,88) { // yingyang #f0f058
    apply_character_cycle_four_colors(
    rgb(245, 245, 245),
    rgb(60, 60, 60),
    rgb(245, 245, 245),
    rgb(15, 15, 15),
    3,
    0.15
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,92) { // nature #f0f05c
    apply_ocean(
    rgb(34, 139, 34),
    rgb(76, 175, 80),
    rgb(139, 195, 74),
    rgb(205, 220, 57),
    3.5
);
    textData.shouldScale = true;
}


TEXT_EFFECT(240,240,96) { // koala  #f0f060
    apply_fractal_color(
    rgb(166, 177, 191),
    rgb(183, 195, 209),
    rgb(203, 215, 226),
    rgb(222, 232, 243),
    rgb(179, 193, 208),
    rgb(133, 149, 168),
    rgb(86, 102, 122),
    0.4
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,100) { //sunflower #f0f064
    apply_ocean(
    rgb(92, 52, 18),
    rgb(230, 126, 20),
    rgb(255, 193, 7),
    rgb(255, 224, 72),
    3.5
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,104) { // exodus #f0f068
    apply_ocean(
    rgb(8, 58, 145),
    rgb(25, 105, 190),
    rgb(62, 190, 225),
    rgb(185, 205, 245),
    3.5
);
    textData.shouldScale = true;
}

// halloween

TEXT_EFFECT(240,240,108) { // witchhunt &#f0f06c
    apply_outline(rgb(25,25,25));
    apply_fractal_color(
    rgb(95, 35, 145),
    rgb(51, 28, 59),
    rgb(115, 55, 155),
    rgb(140, 75, 180),
    rgb(235, 187, 250), 
    rgb(100, 40, 150),
    rgb(75, 40, 110),
    0.4
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,112) { // Jack-O'-Flame &#f0f070
    apply_animated_gradient_7(rgb(255, 95, 31), rgb(255, 139, 61), rgb(255, 172, 72), rgb(255, 110, 50), rgb(255, 73, 0), rgb(215, 85, 29), rgb(175, 68, 20),1.2);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,116) { // Spiderweb &#f0f074
    apply_fractal_color(
    rgb(35, 25, 40),
    rgb(65, 40, 70),
    rgb(110, 70, 115),
    rgb(160, 110, 165),
    rgb(45, 30, 50),
    rgb(125, 80, 135),
    rgb(75, 45, 85),
    0.45
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,120) { // Swamp Poison #f0f078
    apply_fractal_color(
        rgb(12, 35, 8),
        rgb(25, 65, 12),
        rgb(45, 90, 15),
        rgb(75, 125, 20),
        rgb(18, 50, 10),
        rgb(55, 105, 15),
        rgb(7, 25, 5),
        0.5
    );
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,124) { // Blood Moon #f0f07c
    apply_fractal_color(
    rgb(120, 0, 10),
    rgb(70, 0, 5),
    rgb(180, 15, 20),
    rgb(235, 35, 25),
    rgb(100, 5, 10),
    rgb(200, 20, 15),
    rgb(55, 0, 5),
    0.45
);
    textData.shouldScale = true;
}

// halloween


// christmas

TEXT_EFFECT(240,240,128) { // Frozen Wonderland #f0f080
    apply_virus_cycle(
    rgb(240, 255, 255),
    rgb(150, 230, 255),
    rgb(60, 160, 255),
    rgb(15, 45, 120),
    rgb(255, 255, 255),
    rgb(190, 210, 235),
    rgb(100, 130, 180),
    rgb(220, 245, 255),
    40.0,
    0.67
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,132) { // Christmas spirit #f0f084
    apply_virus_cycle(
    rgb(255, 180, 180),
    rgb(255, 65, 65),
    rgb(190, 0, 25),
    rgb(75, 0, 10),
    rgb(180, 255, 190),
    rgb(35, 220, 75),
    rgb(0, 120, 40),
    rgb(0, 45, 15),
    40.0,
    0.67
);
    textData.shouldScale = true;
}


TEXT_EFFECT(240,240,136) { // Candy Cane #f0f088
    apply_animated_gradient_7(rgb(255, 0, 0), rgb(255, 182, 193), rgb(255, 255, 255), rgb(255, 192, 203), rgb(255, 0, 0), rgb(240, 128, 128), rgb(255,255,255), 1.2);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,140) { // Cookie  #f0f08c
    apply_virus_cycle(
    rgb(255, 228, 196),
    rgb(222, 184, 135),
    rgb(205, 133, 63),
    rgb(181, 101, 29),  
    rgb(181, 101, 29), 
    rgb(222, 184, 135),
    rgb(205, 133, 63),
    rgb(255, 228, 196), 
    54.0,
    0.67
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,144) { // Mint #f0f090
    apply_animated_gradient_7(
    rgb(13, 233, 141),
    rgb(150, 245, 185),
    rgb(13, 233, 141),
    rgb(100, 220, 150),
    rgb(35, 190, 105),
    rgb(180, 255, 210),
    rgb(35, 190, 105),
    1.5
);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,148) { // Christmas Aurora #f0f094
    apply_animated_gradient_7(
    rgb(20, 220, 255),
    rgb(35, 190, 255),
    rgb(65, 155, 255),
    rgb(95, 125, 255),
    rgb(125, 95, 255),
    rgb(155, 65, 255),
    rgb(195, 25, 255),
    1.0
);
    textData.shouldScale = true;
}