
TEXT_EFFECT(240, 240, 0) {
    apply_camo(rgb(170, 20, 43), rgb(253, 130, 142), rgb(230, 210, 210), rgb(250, 245, 245), 45.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 4) {
    apply_rainbow();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 8) {
    apply_rainbow();
    textData.shouldScale = true;
}


TEXT_EFFECT(240, 240, 12) { // #f0f00c
    apply_ocean_rainbow(4.0); 
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,20) { // #f0f014 blue
    apply_ocean(rgb(0, 230, 118), rgb(76, 205, 245), rgb(224, 84, 229), rgb(136, 59, 252), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,24) { // #f0f018 green
    apply_ocean(rgb(200, 255, 200), rgb(80, 255, 80), rgb(20, 160, 20), rgb(0, 40, 0), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,28) { // #f0f022 red
    apply_ocean(rgb(255, 0, 0), rgb(255, 80, 80), rgb(160, 20, 20), rgb(40, 0, 0), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,32) { // #f0f020 purple
    apply_ocean(rgb(235,210,255), rgb(180,90,255), rgb(110,30,160), rgb(35,0,55), 3.5);
    textData.shouldScale = true;
}


