TEXT_EFFECT(240, 236, 4) { // #f0ec04
    apply_rainbow_fractal();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 0) { // #f0f000
    apply_pale_rainbow_fractal();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 4) { // #f0f004
    apply_pastel_rainbow();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 8) { //#f0f008
    apply_rainbow();
    textData.shouldScale = true;
}


TEXT_EFFECT(240, 240, 12) { // #f0f00c
    apply_ocean_rainbow(4.0); 
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,20) { // #f0f014 blue
    apply_ocean(rgb(0, 230, 118), rgb(76, 205, 245), rgb(224, 84, 229), rgb(136, 59, 252), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,24) { // #f0f018 green
    apply_ocean(rgb(200, 255, 200), rgb(80, 255, 80), rgb(20, 160, 20), rgb(0, 40, 0), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,28) { // #f0f022 red
    apply_ocean(rgb(255, 0, 0), rgb(255, 80, 80), rgb(160, 20, 20), rgb(40, 0, 0), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,32) { // #f0f020 purple
    apply_ocean(rgb(235,210,255), rgb(180,90,255), rgb(110,30,160), rgb(35,0,55), 3.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,36) {
    apply_character_cycle_seven_colors(rgb(252, 141, 53), rgb(236, 82, 79), rgb(252, 141, 53), rgb(252, 200, 39), rgb(203, 201, 70), rgb(154, 202, 100), rgb(38, 196, 215), 10, 0.15);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,40) { // snap test #f0f028
    apply_ocean(rgb(255,255,255), rgb(200,200,200), rgb(25,25,25), rgb(55,55,55), 1.5);
    apply_shimmer();
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,44) {
    apply_binary(rgb(0,0,0), rgb(0,255,0), 5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240,240,48) {
    apply_quicksilver(rgb(255,209,220), rgb(255,218,185), rgb(253,253,150), rgb(184,242,230), rgb(174,198,207), rgb(205,180,219), rgb(255,255,255), 500.0);
    textData.shouldScale = true;
}


TEXT_EFFECT(240,240,52) {
    apply_fractal_color(rgb(255, 105, 180), rgb(255, 20, 147), rgb(255, 182, 193), rgb(218, 112, 214), rgb(186, 85, 211), rgb(238, 130, 238), rgb(128, 0, 128), 0.4);
    textData.shouldScale = true;
}


