// Player skin RGB -> animation mapping.
// Keep animation implementations in skin_effects.glsl.

#define SKIN_EFFECT(r,g,b,id,speed,intensity) if(skinfx_rgb_match(colorA, skinfx_rgb(r,g,b))) effect = ivec4(id,speed,intensity,FXF_EMISSIVE)

void skinfx_configure(vec3 colorA, out ivec4 effect, out ivec4 effect2) {
    effect = ivec4(0);
    effect2 = ivec4(0);

    SKIN_EFFECT(255,0,255,FX_RAINBOW,255,255);
    SKIN_EFFECT(20,0,40,FX_VOID,170,255);
    SKIN_EFFECT(255,0,0,FX_ENCHANTED,240,255);
    SKIN_EFFECT(0,255,255,FX_HOLOGRAM,220,255);
    SKIN_EFFECT(80,255,180,FX_AURORA,210,230);
    SKIN_EFFECT(255,70,20,FX_INFERNO,235,255);
    SKIN_EFFECT(150,220,255,FX_FROST,225,240);
    SKIN_EFFECT(80,40,220,FX_GALAXY,210,255);
    SKIN_EFFECT(255,90,20,FX_MOLTEN,230,255);
    SKIN_EFFECT(255,210,40,FX_MIDAS,220,255);
    SKIN_EFFECT(40,255,80,FX_TOXIC,215,230);
    SKIN_EFFECT(100,160,255,FX_STORM,210,230);
    SKIN_EFFECT(255,80,220,FX_PRISM,225,230);
    SKIN_EFFECT(180,50,255,FX_HALLOWEEN,225,255);
    SKIN_EFFECT(139,0,0,FX_BLOOD_MOON,255,255);
    SKIN_EFFECT(12,0,25,FX_BLACK_HOLE,180,255);
}

#undef SKIN_EFFECT
