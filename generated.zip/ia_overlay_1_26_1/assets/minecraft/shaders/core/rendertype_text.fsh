#version 330
#define RENDERTYPE_TEXT
#define FSH
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
uniform sampler2D Sampler0;
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
out vec4 fragColor;
#moj_import <spheya_utils.glsl>
#moj_import <text_effects.glsl>
void main() {
    textData.color = vertexColor;
    textData.topColor = vec4(0.0);
    textData.backColor = vec4(0.0);
    textData.isShadow = false;
    textData.doTextureLookup = true;
    textData.shouldScale = false;
    textData.uv = texCoord0;
    textData.uvMin = texCoord0;
    textData.uvMax = texCoord0 + vec2(1.0 / 256.0);
    textData.uvCenter = texCoord0;
    textData.localPosition = texCoord0;
    textData.position = texCoord0 * 256.0;
    textData.characterPosition = texCoord0 * 256.0;
    initTimeValues();
    applyTextEffects();
    vec4 texColor = texture(Sampler0, textData.uv);
    if (!textData.doTextureLookup) texColor = vec4(0.0);
    vec4 color = texColor * textData.color * ColorModulator;
    if (color.a < 0.1) discard;
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
